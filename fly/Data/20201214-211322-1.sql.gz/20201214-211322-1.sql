-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : fly
-- 
-- Part : #1
-- Date : 2020-12-14 21:13:22
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `lovevi_action`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_action`;
CREATE TABLE `lovevi_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text COMMENT '行为规则',
  `log` text COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `lovevi_action`
-- -----------------------------
INSERT INTO `lovevi_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `lovevi_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `lovevi_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '1', '1383285646');
INSERT INTO `lovevi_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '0', '1386139726');
INSERT INTO `lovevi_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '0', '1383285551');
INSERT INTO `lovevi_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `lovevi_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `lovevi_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `lovevi_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `lovevi_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `lovevi_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');

-- -----------------------------
-- Table structure for `lovevi_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_action_log`;
CREATE TABLE `lovevi_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=531 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `lovevi_action_log`
-- -----------------------------
INSERT INTO `lovevi_action_log` VALUES ('54', '10', '1', '1904257316', 'Menu', '106', '操作url：/admin.php?s=/Menu/edit.html', '1', '1485161512');
INSERT INTO `lovevi_action_log` VALUES ('55', '1', '1', '1904257316', 'member', '1', 'admin在2017-01-23 17:00登录了后台', '1', '1485162003');
INSERT INTO `lovevi_action_log` VALUES ('56', '1', '3', '1904257316', 'member', '3', 'test1在2017-01-23 17:02登录了后台', '1', '1485162149');
INSERT INTO `lovevi_action_log` VALUES ('57', '1', '1', '1904257316', 'member', '1', 'admin在2017-01-23 17:02登录了后台', '1', '1485162161');
INSERT INTO `lovevi_action_log` VALUES ('58', '1', '2', '1904257316', 'member', '2', 'test在2017-01-23 17:04登录了后台', '1', '1485162294');
INSERT INTO `lovevi_action_log` VALUES ('59', '1', '1', '1904257316', 'member', '1', 'admin在2017-01-23 17:16登录了后台', '1', '1485162971');
INSERT INTO `lovevi_action_log` VALUES ('60', '1', '1', '248250542', 'member', '1', 'admin在2017-01-23 17:45登录了后台', '1', '1485164731');
INSERT INTO `lovevi_action_log` VALUES ('61', '1', '1', '1904257316', 'member', '1', 'admin在2017-01-23 17:47登录了后台', '1', '1485164837');
INSERT INTO `lovevi_action_log` VALUES ('62', '1', '1', '1904257316', 'member', '1', 'admin在2017-01-23 20:58登录了后台', '1', '1485176311');
INSERT INTO `lovevi_action_log` VALUES ('63', '1', '1', '-593283591', 'member', '1', 'admin在2017-01-23 21:14登录了后台', '1', '1485177297');
INSERT INTO `lovevi_action_log` VALUES ('64', '1', '1', '2073528891', 'member', '1', 'admin在2017-01-23 21:38登录了后台', '1', '1485178702');
INSERT INTO `lovevi_action_log` VALUES ('65', '1', '1', '-593283591', 'member', '1', 'admin在2017-01-23 22:38登录了后台', '1', '1485182325');
INSERT INTO `lovevi_action_log` VALUES ('66', '1', '4', '-593283591', 'member', '4', 'dczj123在2017-01-23 22:42登录了后台', '1', '1485182566');
INSERT INTO `lovevi_action_log` VALUES ('67', '1', '1', '-593283591', 'member', '1', 'admin在2017-01-23 22:52登录了后台', '1', '1485183120');
INSERT INTO `lovevi_action_log` VALUES ('68', '1', '1', '236004752', 'member', '1', 'admin在2017-01-24 11:31登录了后台', '1', '1485228712');
INSERT INTO `lovevi_action_log` VALUES ('69', '1', '1', '1904259022', 'member', '1', 'admin在2017-02-04 09:11登录了后台', '1', '1486170704');
INSERT INTO `lovevi_action_log` VALUES ('70', '1', '1', '1904259022', 'member', '1', 'admin在2017-02-05 14:49登录了后台', '1', '1486277355');
INSERT INTO `lovevi_action_log` VALUES ('71', '1', '5', '1904259022', 'member', '5', 'test在2017-02-05 14:51登录了后台', '1', '1486277487');
INSERT INTO `lovevi_action_log` VALUES ('72', '1', '1', '1904259022', 'member', '1', 'admin在2017-02-05 14:51登录了后台', '1', '1486277510');
INSERT INTO `lovevi_action_log` VALUES ('73', '1', '5', '1904259022', 'member', '5', 'test在2017-02-05 14:52登录了后台', '1', '1486277533');
INSERT INTO `lovevi_action_log` VALUES ('74', '1', '1', '1904259022', 'member', '1', 'admin在2017-02-10 10:12登录了后台', '1', '1486692731');
INSERT INTO `lovevi_action_log` VALUES ('75', '1', '1', '2047087142', 'member', '1', 'admin在2017-02-13 12:23登录了后台', '1', '1486959802');
INSERT INTO `lovevi_action_log` VALUES ('76', '10', '1', '2047087142', 'Menu', '137', '操作url：/admin.php?s=/Menu/add.html', '1', '1486962119');
INSERT INTO `lovevi_action_log` VALUES ('77', '10', '1', '2047087142', 'Menu', '138', '操作url：/admin.php?s=/Menu/add.html', '1', '1486962148');
INSERT INTO `lovevi_action_log` VALUES ('78', '1', '1', '976761770', 'member', '1', 'admin在2017-02-13 15:19登录了后台', '1', '1486970372');
INSERT INTO `lovevi_action_log` VALUES ('79', '1', '1', '976761770', 'member', '1', 'admin在2017-02-13 16:01登录了后台', '1', '1486972907');
INSERT INTO `lovevi_action_log` VALUES ('80', '1', '1', '2047087142', 'member', '1', 'admin在2017-02-13 18:33登录了后台', '1', '1486982015');
INSERT INTO `lovevi_action_log` VALUES ('81', '1', '1', '2047087142', 'member', '1', 'admin在2017-02-13 19:46登录了后台', '1', '1486986377');
INSERT INTO `lovevi_action_log` VALUES ('82', '1', '1', '976761770', 'member', '1', 'admin在2017-02-14 10:01登录了后台', '1', '1487037660');
INSERT INTO `lovevi_action_log` VALUES ('83', '1', '1', '-546787470', 'member', '1', 'admin在2017-02-14 10:19登录了后台', '1', '1487038781');
INSERT INTO `lovevi_action_log` VALUES ('84', '1', '1', '236004752', 'member', '1', 'admin在2017-02-14 10:50登录了后台', '1', '1487040658');
INSERT INTO `lovevi_action_log` VALUES ('85', '1', '1', '236004754', 'member', '1', 'admin在2017-02-14 10:56登录了后台', '1', '1487040982');
INSERT INTO `lovevi_action_log` VALUES ('86', '1', '1', '992881753', 'member', '1', 'admin在2017-02-14 18:14登录了后台', '1', '1487067299');
INSERT INTO `lovevi_action_log` VALUES ('87', '1', '1', '976761770', 'member', '1', 'admin在2017-02-15 09:17登录了后台', '1', '1487121427');
INSERT INTO `lovevi_action_log` VALUES ('88', '1', '1', '-611116538', 'member', '1', 'admin在2017-02-16 16:28登录了后台', '1', '1487233711');
INSERT INTO `lovevi_action_log` VALUES ('89', '1', '1', '2047087142', 'member', '1', 'admin在2017-02-16 17:35登录了后台', '1', '1487237705');
INSERT INTO `lovevi_action_log` VALUES ('90', '1', '1', '-611116538', 'member', '1', 'admin在2017-02-16 17:52登录了后台', '1', '1487238760');
INSERT INTO `lovevi_action_log` VALUES ('91', '10', '1', '2047087142', 'Menu', '139', '操作url：/admin.php?s=/Menu/add.html', '1', '1487240708');
INSERT INTO `lovevi_action_log` VALUES ('92', '10', '1', '2047087142', 'Menu', '139', '操作url：/admin.php?s=/Menu/edit.html', '1', '1487240727');
INSERT INTO `lovevi_action_log` VALUES ('93', '1', '1', '1879470195', 'member', '1', 'admin在2017-02-16 19:25登录了后台', '1', '1487244332');
INSERT INTO `lovevi_action_log` VALUES ('94', '1', '12', '-546784285', 'member', '12', 'qwe123在2017-02-16 20:27登录了后台', '1', '1487248027');
INSERT INTO `lovevi_action_log` VALUES ('95', '1', '12', '-546784285', 'member', '12', 'qwe123在2017-02-16 20:27登录了后台', '1', '1487248075');
INSERT INTO `lovevi_action_log` VALUES ('96', '1', '12', '-546784285', 'member', '12', 'qwe123在2017-02-16 20:30登录了后台', '1', '1487248248');
INSERT INTO `lovevi_action_log` VALUES ('97', '1', '12', '-546784285', 'member', '12', 'qwe123在2017-02-16 20:31登录了后台', '1', '1487248292');
INSERT INTO `lovevi_action_log` VALUES ('98', '1', '1', '2047087142', 'member', '1', 'admin在2017-02-22 18:49登录了后台', '1', '1487760581');
INSERT INTO `lovevi_action_log` VALUES ('99', '1', '1', '-593283769', 'member', '1', 'admin在2017-02-23 15:16登录了后台', '1', '1487834209');
INSERT INTO `lovevi_action_log` VALUES ('100', '1', '1', '-593283769', 'member', '1', 'admin在2017-02-23 15:25登录了后台', '1', '1487834707');
INSERT INTO `lovevi_action_log` VALUES ('101', '1', '1', '2047087142', 'member', '1', 'admin在2017-02-23 17:12登录了后台', '1', '1487841179');
INSERT INTO `lovevi_action_log` VALUES ('102', '1', '1', '-593283769', 'member', '1', 'admin在2017-02-23 18:48登录了后台', '1', '1487846914');
INSERT INTO `lovevi_action_log` VALUES ('103', '1', '1', '-1225422099', 'member', '1', 'admin在2017-02-24 08:36登录了后台', '1', '1487896593');
INSERT INTO `lovevi_action_log` VALUES ('104', '1', '1', '-593283769', 'member', '1', 'admin在2017-02-24 11:28登录了后台', '1', '1487906907');
INSERT INTO `lovevi_action_log` VALUES ('105', '1', '1', '-593283769', 'member', '1', 'admin在2017-02-24 13:27登录了后台', '1', '1487914037');
INSERT INTO `lovevi_action_log` VALUES ('106', '1', '18', '-593283769', 'member', '18', '老大在2017-02-24 14:30登录了后台', '1', '1487917840');
INSERT INTO `lovevi_action_log` VALUES ('107', '1', '17', '-593283769', 'member', '17', '冲锋车在2017-02-24 14:35登录了后台', '1', '1487918109');
INSERT INTO `lovevi_action_log` VALUES ('108', '1', '16', '-593283769', 'member', '16', '钢铁侠在2017-02-24 14:38登录了后台', '1', '1487918303');
INSERT INTO `lovevi_action_log` VALUES ('109', '1', '15', '-593283769', 'member', '15', '超人在2017-02-24 14:41登录了后台', '1', '1487918464');
INSERT INTO `lovevi_action_log` VALUES ('110', '1', '14', '-593283769', 'member', '14', '大圣在2017-02-24 14:41登录了后台', '1', '1487918517');
INSERT INTO `lovevi_action_log` VALUES ('111', '1', '14', '-593283769', 'member', '14', '大圣在2017-02-24 15:13登录了后台', '1', '1487920426');
INSERT INTO `lovevi_action_log` VALUES ('112', '1', '1', '-593283769', 'member', '1', 'admin在2017-02-24 20:35登录了后台', '1', '1487939749');
INSERT INTO `lovevi_action_log` VALUES ('113', '1', '18', '-593283769', 'member', '18', '老大在2017-02-24 20:43登录了后台', '1', '1487940186');
INSERT INTO `lovevi_action_log` VALUES ('114', '1', '1', '-593283769', 'member', '1', 'admin在2017-02-24 21:05登录了后台', '1', '1487941549');
INSERT INTO `lovevi_action_log` VALUES ('115', '1', '1', '2074868148', 'member', '1', 'admin在2017-02-25 06:38登录了后台', '1', '1487975938');
INSERT INTO `lovevi_action_log` VALUES ('116', '10', '1', '2074868148', 'Menu', '75', '操作url：/admin.php?s=/Menu/edit.html', '1', '1487977436');
INSERT INTO `lovevi_action_log` VALUES ('117', '1', '1', '-1225606523', 'member', '1', 'admin在2017-02-25 09:34登录了后台', '1', '1487986453');
INSERT INTO `lovevi_action_log` VALUES ('118', '1', '1', '-1225606523', 'member', '1', 'admin在2017-02-25 16:01登录了后台', '1', '1488009709');
INSERT INTO `lovevi_action_log` VALUES ('119', '1', '18', '-1225606523', 'member', '18', '老大在2017-02-25 16:20登录了后台', '1', '1488010800');
INSERT INTO `lovevi_action_log` VALUES ('120', '1', '18', '-1225606523', 'member', '18', '老大在2017-02-25 16:23登录了后台', '1', '1488011021');
INSERT INTO `lovevi_action_log` VALUES ('121', '1', '1', '-1225606523', 'member', '1', 'admin在2017-02-25 16:25登录了后台', '1', '1488011150');
INSERT INTO `lovevi_action_log` VALUES ('122', '1', '18', '-1225606523', 'member', '18', '老大在2017-02-25 16:27登录了后台', '1', '1488011264');
INSERT INTO `lovevi_action_log` VALUES ('123', '1', '18', '-1225606523', 'member', '18', '老大在2017-02-25 17:19登录了后台', '1', '1488014358');
INSERT INTO `lovevi_action_log` VALUES ('124', '1', '18', '-1225606523', 'member', '18', '老大在2017-02-25 17:37登录了后台', '1', '1488015435');
INSERT INTO `lovevi_action_log` VALUES ('125', '1', '15', '-1225606523', 'member', '15', '超人在2017-02-25 18:29登录了后台', '1', '1488018579');
INSERT INTO `lovevi_action_log` VALUES ('126', '1', '1', '2074868148', 'member', '1', 'admin在2017-02-25 19:57登录了后台', '1', '1488023855');
INSERT INTO `lovevi_action_log` VALUES ('127', '1', '19', '2074868148', 'member', '19', 'test在2017-02-25 19:58登录了后台', '1', '1488023919');
INSERT INTO `lovevi_action_log` VALUES ('128', '1', '18', '-1225606523', 'member', '18', '老大在2017-02-25 21:03登录了后台', '1', '1488027816');
INSERT INTO `lovevi_action_log` VALUES ('129', '1', '16', '-1225606523', 'member', '16', '钢铁侠在2017-02-25 22:55登录了后台', '1', '1488034519');
INSERT INTO `lovevi_action_log` VALUES ('130', '1', '1', '-1225606523', 'member', '1', 'admin在2017-02-25 22:56登录了后台', '1', '1488034581');
INSERT INTO `lovevi_action_log` VALUES ('131', '1', '20', '-1225606523', 'member', '20', '大哥大在2017-02-25 23:43登录了后台', '1', '1488037400');
INSERT INTO `lovevi_action_log` VALUES ('132', '1', '1', '-1225606523', 'member', '1', 'admin在2017-02-26 00:11登录了后台', '1', '1488039101');
INSERT INTO `lovevi_action_log` VALUES ('133', '1', '1', '2074868148', 'member', '1', 'admin在2017-02-26 08:42登录了后台', '1', '1488069726');
INSERT INTO `lovevi_action_log` VALUES ('134', '1', '19', '2074868148', 'member', '19', 'test在2017-02-26 08:42登录了后台', '1', '1488069745');
INSERT INTO `lovevi_action_log` VALUES ('135', '1', '18', '-1225606523', 'member', '18', '老大在2017-02-26 10:57登录了后台', '1', '1488077831');
INSERT INTO `lovevi_action_log` VALUES ('136', '1', '1', '2074868148', 'member', '1', 'admin在2017-02-26 11:30登录了后台', '1', '1488079815');
INSERT INTO `lovevi_action_log` VALUES ('137', '10', '1', '2074868148', 'Menu', '27', '操作url：/admin.php?s=/Menu/edit.html', '1', '1488079832');
INSERT INTO `lovevi_action_log` VALUES ('138', '10', '1', '2074868148', 'Menu', '27', '操作url：/admin.php?s=/Menu/edit.html', '1', '1488079880');
INSERT INTO `lovevi_action_log` VALUES ('139', '1', '18', '-1225606523', 'member', '18', '老大在2017-02-26 11:34登录了后台', '1', '1488080044');
INSERT INTO `lovevi_action_log` VALUES ('140', '1', '1', '-1225606523', 'member', '1', 'admin在2017-02-26 11:36登录了后台', '1', '1488080165');
INSERT INTO `lovevi_action_log` VALUES ('141', '1', '18', '-1225606523', 'member', '18', '老大在2017-02-26 11:44登录了后台', '1', '1488080690');
INSERT INTO `lovevi_action_log` VALUES ('142', '1', '1', '-1225606523', 'member', '1', 'admin在2017-02-26 11:50登录了后台', '1', '1488081023');
INSERT INTO `lovevi_action_log` VALUES ('143', '1', '15', '-1225606523', 'member', '15', '超人在2017-02-26 12:17登录了后台', '1', '1488082647');
INSERT INTO `lovevi_action_log` VALUES ('144', '1', '16', '-1225606523', 'member', '16', '钢铁侠在2017-02-26 12:18登录了后台', '1', '1488082720');
INSERT INTO `lovevi_action_log` VALUES ('145', '1', '17', '-1225606523', 'member', '17', '冲锋车在2017-02-26 12:20登录了后台', '1', '1488082810');
INSERT INTO `lovevi_action_log` VALUES ('146', '1', '18', '-1225606523', 'member', '18', '老大在2017-02-26 12:21登录了后台', '1', '1488082890');
INSERT INTO `lovevi_action_log` VALUES ('147', '1', '1', '-1225606523', 'member', '1', 'admin在2017-02-26 12:22登录了后台', '1', '1488082961');
INSERT INTO `lovevi_action_log` VALUES ('148', '1', '1', '-1347972490', 'member', '1', 'admin在2017-02-26 15:50登录了后台', '1', '1488095421');
INSERT INTO `lovevi_action_log` VALUES ('149', '1', '24', '1934914434', 'member', '24', '可口可乐在2017-02-26 15:54登录了后台', '1', '1488095676');
INSERT INTO `lovevi_action_log` VALUES ('150', '1', '1', '-1225606523', 'member', '1', 'admin在2017-02-26 16:47登录了后台', '1', '1488098875');
INSERT INTO `lovevi_action_log` VALUES ('151', '1', '24', '1934914434', 'member', '24', '可口可乐在2017-02-26 17:27登录了后台', '1', '1488101222');
INSERT INTO `lovevi_action_log` VALUES ('152', '1', '1', '-1225606523', 'member', '1', 'admin在2017-02-26 19:50登录了后台', '1', '1488109852');
INSERT INTO `lovevi_action_log` VALUES ('153', '1', '1', '976761770', 'member', '1', 'admin在2017-02-27 10:55登录了后台', '1', '1488164128');
INSERT INTO `lovevi_action_log` VALUES ('154', '1', '1', '-1225606798', 'member', '1', 'admin在2017-02-27 12:34登录了后台', '1', '1488170059');
INSERT INTO `lovevi_action_log` VALUES ('155', '1', '23', '1934914423', 'member', '23', '美能达在2017-02-27 12:35登录了后台', '1', '1488170132');
INSERT INTO `lovevi_action_log` VALUES ('156', '1', '1', '-1225606798', 'member', '1', 'admin在2017-02-27 13:36登录了后台', '1', '1488173779');
INSERT INTO `lovevi_action_log` VALUES ('157', '1', '18', '-1225606798', 'member', '18', '老大在2017-02-27 13:38登录了后台', '1', '1488173902');
INSERT INTO `lovevi_action_log` VALUES ('158', '1', '1', '-1225606798', 'member', '1', 'admin在2017-02-27 13:40登录了后台', '1', '1488174032');
INSERT INTO `lovevi_action_log` VALUES ('159', '1', '15', '-1225606798', 'member', '15', '超人在2017-02-27 13:51登录了后台', '1', '1488174688');
INSERT INTO `lovevi_action_log` VALUES ('160', '1', '16', '-1225606798', 'member', '16', '钢铁侠在2017-02-27 13:52登录了后台', '1', '1488174756');
INSERT INTO `lovevi_action_log` VALUES ('161', '1', '17', '-1225606798', 'member', '17', '冲锋车在2017-02-27 13:53登录了后台', '1', '1488174839');
INSERT INTO `lovevi_action_log` VALUES ('162', '1', '18', '-1225606798', 'member', '18', '老大在2017-02-27 13:54登录了后台', '1', '1488174884');
INSERT INTO `lovevi_action_log` VALUES ('163', '1', '20', '-1225606798', 'member', '20', '大哥大在2017-02-27 13:55登录了后台', '1', '1488174926');
INSERT INTO `lovevi_action_log` VALUES ('164', '1', '1', '-1225606798', 'member', '1', 'admin在2017-02-27 13:55登录了后台', '1', '1488174951');
INSERT INTO `lovevi_action_log` VALUES ('165', '1', '13', '-1225606798', 'member', '13', 'zckj8899在2017-02-27 14:00登录了后台', '1', '1488175212');
INSERT INTO `lovevi_action_log` VALUES ('166', '1', '1', '-1225606798', 'member', '1', 'admin在2017-02-27 14:00登录了后台', '1', '1488175241');
INSERT INTO `lovevi_action_log` VALUES ('167', '1', '13', '-1225606798', 'member', '13', 'zckj8899在2017-02-27 14:01登录了后台', '1', '1488175282');
INSERT INTO `lovevi_action_log` VALUES ('168', '1', '1', '-1225606798', 'member', '1', 'admin在2017-02-27 14:04登录了后台', '1', '1488175440');
INSERT INTO `lovevi_action_log` VALUES ('169', '1', '1', '1782137973', 'member', '1', 'admin在2017-02-27 16:09登录了后台', '1', '1488182944');
INSERT INTO `lovevi_action_log` VALUES ('170', '1', '1', '1782390402', 'member', '1', 'admin在2017-02-28 22:35登录了后台', '1', '1488292531');
INSERT INTO `lovevi_action_log` VALUES ('171', '1', '1', '1782390402', 'member', '1', 'admin在2017-02-28 22:40登录了后台', '1', '1488292823');
INSERT INTO `lovevi_action_log` VALUES ('172', '1', '23', '1934914699', 'member', '23', '美能达在2017-02-28 22:56登录了后台', '1', '1488293769');
INSERT INTO `lovevi_action_log` VALUES ('173', '1', '18', '1886659939', 'member', '18', '老大在2017-03-01 14:21登录了后台', '1', '1488349263');
INSERT INTO `lovevi_action_log` VALUES ('174', '1', '1', '1886659939', 'member', '1', 'admin在2017-03-01 14:22登录了后台', '1', '1488349330');
INSERT INTO `lovevi_action_log` VALUES ('175', '1', '1', '1934914699', 'member', '1', 'admin在2017-03-01 14:29登录了后台', '1', '1488349745');
INSERT INTO `lovevi_action_log` VALUES ('176', '1', '1', '1934914699', 'member', '1', 'admin在2017-03-01 14:39登录了后台', '1', '1488350380');
INSERT INTO `lovevi_action_log` VALUES ('177', '1', '1', '-593238745', 'member', '1', 'admin在2017-03-01 15:02登录了后台', '1', '1488351741');
INSERT INTO `lovevi_action_log` VALUES ('178', '1', '1', '1934914699', 'member', '1', 'admin在2017-03-01 17:06登录了后台', '1', '1488359213');
INSERT INTO `lovevi_action_log` VALUES ('179', '1', '18', '2000605510', 'member', '18', '老大在2017-03-01 21:18登录了后台', '1', '1488374316');
INSERT INTO `lovevi_action_log` VALUES ('180', '1', '23', '1934915503', 'member', '23', '美能达在2017-03-01 21:35登录了后台', '1', '1488375348');
INSERT INTO `lovevi_action_log` VALUES ('181', '1', '1', '1934915503', 'member', '1', 'admin在2017-03-01 21:42登录了后台', '1', '1488375726');
INSERT INTO `lovevi_action_log` VALUES ('182', '1', '1', '1886659939', 'member', '1', 'admin在2017-03-02 11:42登录了后台', '1', '1488426174');
INSERT INTO `lovevi_action_log` VALUES ('183', '1', '16', '-593238745', 'member', '16', '钢铁侠在2017-03-02 11:49登录了后台', '1', '1488426540');
INSERT INTO `lovevi_action_log` VALUES ('184', '1', '18', '1886656470', 'member', '18', '老大在2017-03-02 15:51登录了后台', '1', '1488441069');
INSERT INTO `lovevi_action_log` VALUES ('185', '1', '18', '1886656470', 'member', '18', '老大在2017-03-02 15:55登录了后台', '1', '1488441300');
INSERT INTO `lovevi_action_log` VALUES ('186', '1', '18', '1886656470', 'member', '18', '老大在2017-03-02 16:39登录了后台', '1', '1488443957');
INSERT INTO `lovevi_action_log` VALUES ('187', '1', '18', '2000583875', 'member', '18', '老大在2017-03-02 19:40登录了后台', '1', '1488454837');
INSERT INTO `lovevi_action_log` VALUES ('188', '1', '1', '1949795652', 'member', '1', 'admin在2017-03-02 20:46登录了后台', '1', '1488458762');
INSERT INTO `lovevi_action_log` VALUES ('189', '1', '1', '1949795652', 'member', '1', 'admin在2017-03-02 20:56登录了后台', '1', '1488459415');
INSERT INTO `lovevi_action_log` VALUES ('190', '1', '16', '1949795652', 'member', '16', '钢铁侠在2017-03-02 21:12登录了后台', '1', '1488460354');
INSERT INTO `lovevi_action_log` VALUES ('191', '1', '1', '1949795652', 'member', '1', 'admin在2017-03-02 21:13登录了后台', '1', '1488460427');
INSERT INTO `lovevi_action_log` VALUES ('192', '1', '1', '-896951258', 'member', '1', 'admin在2017-03-02 22:03登录了后台', '1', '1488463382');
INSERT INTO `lovevi_action_log` VALUES ('193', '1', '18', '1886656470', 'member', '18', '老大在2017-03-03 13:27登录了后台', '1', '1488518876');
INSERT INTO `lovevi_action_log` VALUES ('194', '1', '18', '2000583758', 'member', '18', '老大在2017-03-03 19:32登录了后台', '1', '1488540723');
INSERT INTO `lovevi_action_log` VALUES ('195', '1', '18', '2000604365', 'member', '18', '老大在2017-03-03 21:13登录了后台', '1', '1488546838');
INSERT INTO `lovevi_action_log` VALUES ('196', '1', '18', '2000583758', 'member', '18', '老大在2017-03-03 23:01登录了后台', '1', '1488553311');
INSERT INTO `lovevi_action_log` VALUES ('197', '1', '18', '2000604365', 'member', '18', '老大在2017-03-04 07:44登录了后台', '1', '1488584684');
INSERT INTO `lovevi_action_log` VALUES ('198', '1', '18', '1886656470', 'member', '18', '老大在2017-03-04 11:01登录了后台', '1', '1488596503');
INSERT INTO `lovevi_action_log` VALUES ('199', '1', '18', '2000604403', 'member', '18', '老大在2017-03-05 13:29登录了后台', '1', '1488691758');
INSERT INTO `lovevi_action_log` VALUES ('200', '1', '18', '-1220725790', 'member', '18', '老大在2017-03-05 13:51登录了后台', '1', '1488693114');
INSERT INTO `lovevi_action_log` VALUES ('201', '1', '18', '-1220725825', 'member', '18', '老大在2017-03-05 14:05登录了后台', '1', '1488693927');
INSERT INTO `lovevi_action_log` VALUES ('202', '1', '18', '2000604403', 'member', '18', '老大在2017-03-05 14:18登录了后台', '1', '1488694683');
INSERT INTO `lovevi_action_log` VALUES ('203', '1', '18', '2000605495', 'member', '18', '老大在2017-03-05 19:22登录了后台', '1', '1488712953');
INSERT INTO `lovevi_action_log` VALUES ('204', '1', '1', '-1225606818', 'member', '1', 'admin在2017-03-05 22:29登录了后台', '1', '1488724157');
INSERT INTO `lovevi_action_log` VALUES ('205', '1', '1', '-593282747', 'member', '1', 'admin在2017-03-06 10:59登录了后台', '1', '1488769149');
INSERT INTO `lovevi_action_log` VALUES ('206', '1', '1', '-593282747', 'member', '1', 'admin在2017-03-06 11:04登录了后台', '1', '1488769489');
INSERT INTO `lovevi_action_log` VALUES ('207', '1', '1', '-593282747', 'member', '1', 'admin在2017-03-06 14:40登录了后台', '1', '1488782412');
INSERT INTO `lovevi_action_log` VALUES ('208', '1', '27', '1934915576', 'member', '27', '七彩跑道在2017-03-06 15:34登录了后台', '1', '1488785672');
INSERT INTO `lovevi_action_log` VALUES ('209', '1', '28', '-593282747', 'member', '28', '散客平台在2017-03-06 15:43登录了后台', '1', '1488786224');
INSERT INTO `lovevi_action_log` VALUES ('210', '1', '28', '-593282747', 'member', '28', '散客平台在2017-03-06 15:45登录了后台', '1', '1488786304');
INSERT INTO `lovevi_action_log` VALUES ('211', '1', '28', '-593282747', 'member', '28', '散客平台在2017-03-06 15:45登录了后台', '1', '1488786345');
INSERT INTO `lovevi_action_log` VALUES ('212', '1', '1', '-593282747', 'member', '1', 'admin在2017-03-06 15:46登录了后台', '1', '1488786381');
INSERT INTO `lovevi_action_log` VALUES ('213', '1', '28', '-593282747', 'member', '28', '散客平台在2017-03-06 15:47登录了后台', '1', '1488786449');
INSERT INTO `lovevi_action_log` VALUES ('214', '1', '1', '-593282747', 'member', '1', 'admin在2017-03-06 15:48登录了后台', '1', '1488786519');
INSERT INTO `lovevi_action_log` VALUES ('215', '1', '28', '-593282747', 'member', '28', '散客平台在2017-03-06 15:56登录了后台', '1', '1488786996');
INSERT INTO `lovevi_action_log` VALUES ('216', '1', '1', '-593282747', 'member', '1', 'admin在2017-03-06 15:58登录了后台', '1', '1488787124');
INSERT INTO `lovevi_action_log` VALUES ('217', '1', '28', '-593282747', 'member', '28', '散客平台在2017-03-06 16:02登录了后台', '1', '1488787325');
INSERT INTO `lovevi_action_log` VALUES ('218', '1', '1', '-593282747', 'member', '1', 'admin在2017-03-06 16:02登录了后台', '1', '1488787370');
INSERT INTO `lovevi_action_log` VALUES ('219', '1', '28', '-593282747', 'member', '28', '散客平台在2017-03-06 17:10登录了后台', '1', '1488791432');
INSERT INTO `lovevi_action_log` VALUES ('220', '1', '1', '-593282747', 'member', '1', 'admin在2017-03-06 18:14登录了后台', '1', '1488795297');
INSERT INTO `lovevi_action_log` VALUES ('221', '1', '27', '-593282747', 'member', '27', '七彩跑道在2017-03-06 19:16登录了后台', '1', '1488798983');
INSERT INTO `lovevi_action_log` VALUES ('222', '1', '1', '-593282747', 'member', '1', 'admin在2017-03-06 20:07登录了后台', '1', '1488802070');
INSERT INTO `lovevi_action_log` VALUES ('223', '1', '27', '-593282747', 'member', '27', '七彩跑道在2017-03-06 20:27登录了后台', '1', '1488803268');
INSERT INTO `lovevi_action_log` VALUES ('224', '1', '27', '-593282747', 'member', '27', '七彩跑道在2017-03-06 21:54登录了后台', '1', '1488808476');
INSERT INTO `lovevi_action_log` VALUES ('225', '1', '1', '-593282747', 'member', '1', 'admin在2017-03-06 22:07登录了后台', '1', '1488809220');
INSERT INTO `lovevi_action_log` VALUES ('226', '1', '27', '-593282747', 'member', '27', '七彩跑道在2017-03-06 22:09登录了后台', '1', '1488809346');
INSERT INTO `lovevi_action_log` VALUES ('227', '1', '1', '-593282673', 'member', '1', 'admin在2017-03-07 08:46登录了后台', '1', '1488847603');
INSERT INTO `lovevi_action_log` VALUES ('228', '1', '27', '-593282673', 'member', '27', '七彩跑道在2017-03-07 08:47登录了后台', '1', '1488847670');
INSERT INTO `lovevi_action_log` VALUES ('229', '1', '27', '-593282673', 'member', '27', '七彩跑道在2017-03-07 09:52登录了后台', '1', '1488851533');
INSERT INTO `lovevi_action_log` VALUES ('230', '1', '1', '1904225587', 'member', '1', 'admin在2017-03-13 18:41登录了后台', '1', '1489401690');
INSERT INTO `lovevi_action_log` VALUES ('231', '1', '1', '976761770', 'member', '1', 'admin在2017-03-16 08:48登录了后台', '1', '1489625291');
INSERT INTO `lovevi_action_log` VALUES ('232', '10', '1', '976761770', 'Menu', '140', '操作url：/admin.php?s=/Menu/add.html', '1', '1489625562');
INSERT INTO `lovevi_action_log` VALUES ('233', '10', '1', '976761770', 'Menu', '141', '操作url：/admin.php?s=/Menu/add.html', '1', '1489625608');
INSERT INTO `lovevi_action_log` VALUES ('234', '10', '1', '976761770', 'Menu', '141', '操作url：/admin.php?s=/Menu/edit.html', '1', '1489625642');
INSERT INTO `lovevi_action_log` VALUES ('235', '1', '1', '976761770', 'member', '1', 'admin在2017-03-16 09:53登录了后台', '1', '1489629180');
INSERT INTO `lovevi_action_log` VALUES ('236', '1', '1', '1904225587', 'member', '1', 'admin在2017-03-16 11:43登录了后台', '1', '1489635797');
INSERT INTO `lovevi_action_log` VALUES ('237', '1', '1', '1904225587', 'member', '1', 'admin在2017-03-16 16:51登录了后台', '1', '1489654308');
INSERT INTO `lovevi_action_log` VALUES ('238', '1', '1', '1904225587', 'member', '1', 'admin在2017-03-16 19:29登录了后台', '1', '1489663793');
INSERT INTO `lovevi_action_log` VALUES ('239', '1', '1', '976761770', 'member', '1', 'admin在2017-03-17 09:03登录了后台', '1', '1489712627');
INSERT INTO `lovevi_action_log` VALUES ('240', '1', '1', '1904225587', 'member', '1', 'admin在2017-03-17 12:46登录了后台', '1', '1489725978');
INSERT INTO `lovevi_action_log` VALUES ('241', '10', '1', '1904225587', 'Menu', '141', '操作url：/admin.php?s=/Menu/edit.html', '1', '1489726406');
INSERT INTO `lovevi_action_log` VALUES ('242', '1', '1', '976761770', 'member', '1', 'admin在2017-03-17 14:45登录了后台', '1', '1489733143');
INSERT INTO `lovevi_action_log` VALUES ('243', '1', '1', '1904295548', 'member', '1', 'admin在2017-03-17 14:49登录了后台', '1', '1489733369');
INSERT INTO `lovevi_action_log` VALUES ('244', '1', '1', '976761770', 'member', '1', 'admin在2017-03-17 16:10登录了后台', '1', '1489738237');
INSERT INTO `lovevi_action_log` VALUES ('245', '1', '1', '1904225587', 'member', '1', 'admin在2017-03-17 16:51登录了后台', '1', '1489740712');
INSERT INTO `lovevi_action_log` VALUES ('246', '1', '1', '976761770', 'member', '1', 'admin在2017-03-23 15:44登录了后台', '1', '1490255081');
INSERT INTO `lovevi_action_log` VALUES ('247', '1', '1', '1904225587', 'member', '1', 'admin在2017-03-24 20:31登录了后台', '1', '1490358690');
INSERT INTO `lovevi_action_log` VALUES ('248', '1', '1', '1904225587', 'member', '1', 'admin在2017-03-25 13:27登录了后台', '1', '1490419655');
INSERT INTO `lovevi_action_log` VALUES ('249', '1', '1', '1967868805', 'member', '1', 'admin在2017-03-25 19:08登录了后台', '1', '1490440100');
INSERT INTO `lovevi_action_log` VALUES ('250', '1', '1', '1967868805', 'member', '1', 'admin在2017-03-25 19:18登录了后台', '1', '1490440694');
INSERT INTO `lovevi_action_log` VALUES ('251', '1', '1', '1967868805', 'member', '1', 'admin在2017-03-25 19:51登录了后台', '1', '1490442717');
INSERT INTO `lovevi_action_log` VALUES ('252', '1', '1', '1967868805', 'member', '1', 'admin在2017-03-26 10:59登录了后台', '1', '1490497159');
INSERT INTO `lovevi_action_log` VALUES ('253', '1', '32', '1967868805', 'member', '32', 'titi在2017-03-26 16:26登录了后台', '1', '1490516775');
INSERT INTO `lovevi_action_log` VALUES ('254', '1', '1', '1967868805', 'member', '1', 'admin在2017-03-27 21:47登录了后台', '1', '1490622476');
INSERT INTO `lovevi_action_log` VALUES ('255', '1', '1', '1967868805', 'member', '1', 'admin在2017-03-28 09:22登录了后台', '1', '1490664143');
INSERT INTO `lovevi_action_log` VALUES ('256', '1', '1', '1904225587', 'member', '1', 'admin在2017-03-28 19:31登录了后台', '1', '1490700677');
INSERT INTO `lovevi_action_log` VALUES ('257', '1', '1', '976761770', 'member', '1', 'admin在2017-03-29 09:05登录了后台', '1', '1490749556');
INSERT INTO `lovevi_action_log` VALUES ('258', '1', '1', '1967868805', 'member', '1', 'admin在2017-03-29 11:39登录了后台', '1', '1490758796');
INSERT INTO `lovevi_action_log` VALUES ('259', '1', '1', '1967868805', 'member', '1', 'admin在2017-03-29 20:27登录了后台', '1', '1490790477');
INSERT INTO `lovevi_action_log` VALUES ('260', '1', '1', '1967868805', 'member', '1', 'admin在2017-03-31 10:50登录了后台', '1', '1490928616');
INSERT INTO `lovevi_action_log` VALUES ('261', '1', '34', '1967868805', 'member', '34', 'dog在2017-03-31 12:40登录了后台', '1', '1490935246');
INSERT INTO `lovevi_action_log` VALUES ('262', '1', '1', '1967868805', 'member', '1', 'admin在2017-03-31 13:42登录了后台', '1', '1490938936');
INSERT INTO `lovevi_action_log` VALUES ('263', '1', '1', '2074868964', 'member', '1', 'admin在2017-04-01 21:00登录了后台', '1', '1491051616');
INSERT INTO `lovevi_action_log` VALUES ('264', '1', '1', '2074868964', 'member', '1', 'admin在2017-04-02 19:23登录了后台', '1', '1491132227');
INSERT INTO `lovevi_action_log` VALUES ('265', '10', '1', '2074868964', 'Menu', '142', '操作url：/admin.php?s=/Menu/add.html', '1', '1491132395');
INSERT INTO `lovevi_action_log` VALUES ('266', '10', '1', '2074868964', 'Menu', '142', '操作url：/admin.php?s=/Menu/edit.html', '1', '1491132408');
INSERT INTO `lovevi_action_log` VALUES ('267', '10', '1', '2074868964', 'Menu', '142', '操作url：/admin.php?s=/Menu/edit.html', '1', '1491132417');
INSERT INTO `lovevi_action_log` VALUES ('268', '1', '1', '1967869860', 'member', '1', 'admin在2017-04-02 21:20登录了后台', '1', '1491139247');
INSERT INTO `lovevi_action_log` VALUES ('269', '1', '34', '1967869860', 'member', '34', 'dog在2017-04-02 21:24登录了后台', '1', '1491139464');
INSERT INTO `lovevi_action_log` VALUES ('270', '1', '1', '1967854364', 'member', '1', 'admin在2017-04-06 15:10登录了后台', '1', '1491462649');
INSERT INTO `lovevi_action_log` VALUES ('271', '1', '1', '976761770', 'member', '1', 'admin在2017-04-07 08:04登录了后台', '1', '1491523481');
INSERT INTO `lovevi_action_log` VALUES ('272', '1', '1', '976761770', 'member', '1', 'admin在2017-04-07 09:22登录了后台', '1', '1491528137');
INSERT INTO `lovevi_action_log` VALUES ('273', '1', '1', '976761770', 'member', '1', 'admin在2017-04-07 10:42登录了后台', '1', '1491532927');
INSERT INTO `lovevi_action_log` VALUES ('274', '1', '1', '976761770', 'member', '1', 'admin在2017-04-07 11:36登录了后台', '1', '1491536172');
INSERT INTO `lovevi_action_log` VALUES ('275', '1', '1', '2047087409', 'member', '1', 'admin在2017-04-11 18:57登录了后台', '1', '1491908259');
INSERT INTO `lovevi_action_log` VALUES ('276', '1', '1', '2047087409', 'member', '1', 'admin在2017-04-12 20:15登录了后台', '1', '1491999325');
INSERT INTO `lovevi_action_log` VALUES ('277', '1', '1', '2047087409', 'member', '1', 'admin在2017-04-23 20:17登录了后台', '1', '1492949833');
INSERT INTO `lovevi_action_log` VALUES ('278', '1', '1', '976761770', 'member', '1', 'admin在2017-04-25 16:33登录了后台', '1', '1493109200');
INSERT INTO `lovevi_action_log` VALUES ('279', '1', '1', '2047087409', 'member', '1', 'admin在2017-04-25 18:54登录了后台', '1', '1493117696');
INSERT INTO `lovevi_action_log` VALUES ('280', '1', '1', '2047087409', 'member', '1', 'admin在2017-04-25 21:14登录了后台', '1', '1493126096');
INSERT INTO `lovevi_action_log` VALUES ('281', '1', '1', '2047087409', 'member', '1', 'admin在2017-04-26 13:15登录了后台', '1', '1493183717');
INSERT INTO `lovevi_action_log` VALUES ('282', '1', '1', '2047087409', 'member', '1', 'admin在2017-04-30 16:42登录了后台', '1', '1493541748');
INSERT INTO `lovevi_action_log` VALUES ('283', '1', '1', '2047087409', 'member', '1', 'admin在2017-05-22 14:08登录了后台', '1', '1495433280');
INSERT INTO `lovevi_action_log` VALUES ('284', '1', '1', '-1263724288', 'member', '1', 'admin在2017-05-22 14:09登录了后台', '1', '1495433380');
INSERT INTO `lovevi_action_log` VALUES ('285', '1', '1', '2090915900', 'member', '1', 'admin在2017-05-30 20:23登录了后台', '1', '1496147039');
INSERT INTO `lovevi_action_log` VALUES ('286', '1', '1', '1904225400', 'member', '1', 'admin在2017-07-17 12:00登录了后台', '1', '1500264017');
INSERT INTO `lovevi_action_log` VALUES ('287', '1', '1', '720607571', 'member', '1', 'admin在2017-07-17 12:01登录了后台', '1', '1500264097');
INSERT INTO `lovevi_action_log` VALUES ('288', '1', '1', '1904257798', 'member', '1', 'admin在2017-08-03 14:58登录了后台', '1', '1501743508');
INSERT INTO `lovevi_action_log` VALUES ('289', '1', '1', '1904257798', 'member', '1', 'admin在2017-08-05 20:14登录了后台', '1', '1501935262');
INSERT INTO `lovevi_action_log` VALUES ('290', '10', '1', '1904257798', 'Menu', '143', '操作url：/admin.php?s=/Menu/add.html', '1', '1501939405');
INSERT INTO `lovevi_action_log` VALUES ('291', '10', '1', '1904257798', 'Menu', '143', '操作url：/admin.php?s=/Menu/edit.html', '1', '1501939419');
INSERT INTO `lovevi_action_log` VALUES ('292', '10', '1', '1904257798', 'Menu', '144', '操作url：/admin.php?s=/Menu/add.html', '1', '1501939433');
INSERT INTO `lovevi_action_log` VALUES ('293', '10', '1', '1904257798', 'Menu', '145', '操作url：/admin.php?s=/Menu/add.html', '1', '1501939466');
INSERT INTO `lovevi_action_log` VALUES ('294', '10', '1', '1904257798', 'Menu', '146', '操作url：/admin.php?s=/Menu/add.html', '1', '1501939493');
INSERT INTO `lovevi_action_log` VALUES ('295', '10', '1', '1904257798', 'Menu', '147', '操作url：/admin.php?s=/Menu/add.html', '1', '1501939528');
INSERT INTO `lovevi_action_log` VALUES ('296', '10', '1', '1904257798', 'Menu', '148', '操作url：/admin.php?s=/Menu/add.html', '1', '1501939549');
INSERT INTO `lovevi_action_log` VALUES ('297', '10', '1', '1904257798', 'Menu', '149', '操作url：/admin.php?s=/Menu/add.html', '1', '1501939622');
INSERT INTO `lovevi_action_log` VALUES ('298', '10', '1', '1904257798', 'Menu', '150', '操作url：/admin.php?s=/Menu/add.html', '1', '1501939672');
INSERT INTO `lovevi_action_log` VALUES ('299', '10', '1', '1904257798', 'Menu', '151', '操作url：/admin.php?s=/Menu/add.html', '1', '1501939696');
INSERT INTO `lovevi_action_log` VALUES ('300', '1', '1', '1904257798', 'member', '1', 'admin在2017-08-06 09:16登录了后台', '1', '1501982205');
INSERT INTO `lovevi_action_log` VALUES ('301', '10', '1', '1904257798', 'Menu', '144', '操作url：/admin.php?s=/Menu/edit.html', '1', '1501984114');
INSERT INTO `lovevi_action_log` VALUES ('302', '10', '1', '1904257798', 'Menu', '152', '操作url：/admin.php?s=/Menu/add.html', '1', '1501984141');
INSERT INTO `lovevi_action_log` VALUES ('303', '10', '1', '1904257798', 'Menu', '153', '操作url：/admin.php?s=/Menu/add.html', '1', '1501984157');
INSERT INTO `lovevi_action_log` VALUES ('304', '10', '1', '1904257798', 'Menu', '143', '操作url：/admin.php?s=/Menu/edit.html', '1', '1501984173');
INSERT INTO `lovevi_action_log` VALUES ('305', '10', '1', '1904257798', 'Menu', '134', '操作url：/admin.php?s=/Menu/edit.html', '1', '1501985071');
INSERT INTO `lovevi_action_log` VALUES ('306', '10', '1', '1904257798', 'Menu', '133', '操作url：/admin.php?s=/Menu/edit.html', '1', '1502002147');
INSERT INTO `lovevi_action_log` VALUES ('307', '10', '1', '1904257798', 'Menu', '149', '操作url：/admin.php?s=/Menu/edit.html', '1', '1502002163');
INSERT INTO `lovevi_action_log` VALUES ('308', '10', '1', '1904257798', 'Menu', '154', '操作url：/admin.php?s=/Menu/add.html', '1', '1502002182');
INSERT INTO `lovevi_action_log` VALUES ('309', '10', '1', '1904257798', 'Menu', '150', '操作url：/admin.php?s=/Menu/edit.html', '1', '1502002597');
INSERT INTO `lovevi_action_log` VALUES ('310', '1', '1', '1904257798', 'member', '1', 'admin在2017-08-07 11:15登录了后台', '1', '1502075721');
INSERT INTO `lovevi_action_log` VALUES ('311', '1', '1', '1904257798', 'member', '1', 'admin在2017-08-08 14:49登录了后台', '1', '1502174941');
INSERT INTO `lovevi_action_log` VALUES ('312', '1', '1', '1904257890', 'member', '1', 'admin在2017-08-10 11:36登录了后台', '1', '1502336193');
INSERT INTO `lovevi_action_log` VALUES ('313', '1', '1', '1904257890', 'member', '1', 'admin在2017-08-13 12:25登录了后台', '1', '1502598335');
INSERT INTO `lovevi_action_log` VALUES ('314', '10', '1', '1904257890', 'Menu', '16', '操作url：/admin.php?s=/Menu/edit.html', '1', '1502598377');
INSERT INTO `lovevi_action_log` VALUES ('315', '10', '1', '1904257890', 'Menu', '142', '操作url：/admin.php?s=/Menu/edit.html', '1', '1502598388');
INSERT INTO `lovevi_action_log` VALUES ('316', '10', '1', '1904257890', 'Menu', '140', '操作url：/admin.php?s=/Menu/edit.html', '1', '1502598400');
INSERT INTO `lovevi_action_log` VALUES ('317', '10', '1', '1904257890', 'Menu', '127', '操作url：/admin.php?s=/Menu/edit.html', '1', '1502598407');
INSERT INTO `lovevi_action_log` VALUES ('318', '10', '1', '1904257890', 'Menu', '126', '操作url：/admin.php?s=/Menu/edit.html', '1', '1502598412');
INSERT INTO `lovevi_action_log` VALUES ('319', '10', '1', '1904257890', 'Menu', '139', '操作url：/admin.php?s=/Menu/edit.html', '1', '1502598426');
INSERT INTO `lovevi_action_log` VALUES ('320', '10', '1', '1904257890', 'Menu', '138', '操作url：/admin.php?s=/Menu/edit.html', '1', '1502598433');
INSERT INTO `lovevi_action_log` VALUES ('321', '10', '1', '1904257890', 'Menu', '137', '操作url：/admin.php?s=/Menu/edit.html', '1', '1502598438');
INSERT INTO `lovevi_action_log` VALUES ('322', '1', '1', '1904257890', 'member', '1', 'admin在2017-08-14 13:33登录了后台', '1', '1502688811');
INSERT INTO `lovevi_action_log` VALUES ('323', '1', '1', '242845404', 'member', '1', 'admin在2017-08-14 13:37登录了后台', '1', '1502689058');
INSERT INTO `lovevi_action_log` VALUES ('324', '10', '1', '2074867920', 'Menu', '149', '操作url：/admin.php?s=/Menu/edit.html', '1', '1513167174');
INSERT INTO `lovevi_action_log` VALUES ('325', '10', '1', '2074867920', 'Menu', '155', '操作url：/admin.php?s=/Menu/add.html', '1', '1513170683');
INSERT INTO `lovevi_action_log` VALUES ('326', '1', '1', '976761770', 'member', '1', 'admin在2017-12-14 08:17登录了后台', '1', '1513210672');
INSERT INTO `lovevi_action_log` VALUES ('327', '10', '1', '976761770', 'Menu', '134', '操作url：/admin.php?s=/Menu/edit.html', '1', '1513211897');
INSERT INTO `lovevi_action_log` VALUES ('328', '10', '1', '976761770', 'Menu', '156', '操作url：/admin.php?s=/Menu/add.html', '1', '1513211992');
INSERT INTO `lovevi_action_log` VALUES ('329', '10', '1', '976761770', 'Menu', '157', '操作url：/admin.php?s=/Menu/add.html', '1', '1513212011');
INSERT INTO `lovevi_action_log` VALUES ('330', '10', '1', '976761770', 'Menu', '135', '操作url：/admin.php?s=/Menu/edit.html', '1', '1513212018');
INSERT INTO `lovevi_action_log` VALUES ('331', '10', '1', '976761770', 'Menu', '134', '操作url：/admin.php?s=/Menu/edit.html', '1', '1513212052');
INSERT INTO `lovevi_action_log` VALUES ('332', '10', '1', '976761770', 'Menu', '158', '操作url：/admin.php?s=/Menu/add.html', '1', '1513212152');
INSERT INTO `lovevi_action_log` VALUES ('333', '1', '1', '976761770', 'member', '1', 'admin在2017-12-14 08:52登录了后台', '1', '1513212743');
INSERT INTO `lovevi_action_log` VALUES ('334', '1', '1', '2074867920', 'member', '1', 'admin在2017-12-14 19:09登录了后台', '1', '1513249794');
INSERT INTO `lovevi_action_log` VALUES ('335', '1', '1', '1904225794', 'member', '1', 'admin在2017-12-17 12:54登录了后台', '1', '1513486447');
INSERT INTO `lovevi_action_log` VALUES ('336', '10', '1', '1904225794', 'Menu', '159', '操作url：/admin.php?s=/Menu/add.html', '1', '1513486517');
INSERT INTO `lovevi_action_log` VALUES ('337', '10', '1', '1904225794', 'Menu', '160', '操作url：/admin.php?s=/Menu/add.html', '1', '1513486553');
INSERT INTO `lovevi_action_log` VALUES ('338', '1', '1', '1904225794', 'member', '1', 'admin在2017-12-24 06:26登录了后台', '1', '1514067967');
INSERT INTO `lovevi_action_log` VALUES ('339', '10', '1', '1904225794', 'Menu', '137', '操作url：/admin.php?s=/Menu/edit.html', '1', '1514068035');
INSERT INTO `lovevi_action_log` VALUES ('340', '10', '1', '1904225794', 'Menu', '138', '操作url：/admin.php?s=/Menu/edit.html', '1', '1514068042');
INSERT INTO `lovevi_action_log` VALUES ('341', '1', '1', '1904257883', 'member', '1', 'admin在2017-12-26 18:46登录了后台', '1', '1514285173');
INSERT INTO `lovevi_action_log` VALUES ('342', '1', '1', '1904257883', 'member', '1', 'admin在2017-12-27 18:50登录了后台', '1', '1514371829');
INSERT INTO `lovevi_action_log` VALUES ('343', '1', '1', '976761770', 'member', '1', 'admin在2017-12-28 09:49登录了后台', '1', '1514425750');
INSERT INTO `lovevi_action_log` VALUES ('344', '1', '1', '1904257883', 'member', '1', 'admin在2017-12-28 20:27登录了后台', '1', '1514464066');
INSERT INTO `lovevi_action_log` VALUES ('345', '1', '1', '1904257883', 'member', '1', 'admin在2017-12-29 21:33登录了后台', '1', '1514554408');
INSERT INTO `lovevi_action_log` VALUES ('346', '1', '1', '1904257883', 'member', '1', 'admin在2017-12-30 18:43登录了后台', '1', '1514630611');
INSERT INTO `lovevi_action_log` VALUES ('347', '1', '1', '1904257883', 'member', '1', 'admin在2017-12-31 16:26登录了后台', '1', '1514708774');
INSERT INTO `lovevi_action_log` VALUES ('348', '1', '1', '1904257883', 'member', '1', 'admin在2017-12-31 16:36登录了后台', '1', '1514709402');
INSERT INTO `lovevi_action_log` VALUES ('349', '1', '1', '1904257883', 'member', '1', 'admin在2018-01-01 17:58登录了后台', '1', '1514800684');
INSERT INTO `lovevi_action_log` VALUES ('350', '1', '1', '1904257883', 'member', '1', 'admin在2018-01-01 18:13登录了后台', '1', '1514801607');
INSERT INTO `lovevi_action_log` VALUES ('351', '1', '1', '1904257883', 'member', '1', 'admin在2018-01-01 19:20登录了后台', '1', '1514805613');
INSERT INTO `lovevi_action_log` VALUES ('352', '1', '1', '1904257883', 'member', '1', 'admin在2018-01-02 11:32登录了后台', '1', '1514863926');
INSERT INTO `lovevi_action_log` VALUES ('353', '1', '1', '1904258219', 'member', '1', 'admin在2018-01-02 18:02登录了后台', '1', '1514887359');
INSERT INTO `lovevi_action_log` VALUES ('354', '1', '1', '1904258219', 'member', '1', 'admin在2018-01-02 21:13登录了后台', '1', '1514898796');
INSERT INTO `lovevi_action_log` VALUES ('355', '1', '1', '993728074', 'member', '1', 'admin在2018-01-04 14:49登录了后台', '1', '1515048555');
INSERT INTO `lovevi_action_log` VALUES ('356', '1', '1', '993728074', 'member', '1', 'admin在2018-01-04 14:52登录了后台', '1', '1515048766');
INSERT INTO `lovevi_action_log` VALUES ('357', '1', '1', '993728074', 'member', '1', 'admin在2018-01-04 14:57登录了后台', '1', '1515049022');
INSERT INTO `lovevi_action_log` VALUES ('358', '1', '1', '993728074', 'member', '1', 'admin在2018-01-04 15:02登录了后台', '1', '1515049336');
INSERT INTO `lovevi_action_log` VALUES ('359', '10', '1', '993728074', 'Menu', '134', '操作url：/admin.php?s=/Menu/edit.html', '1', '1515049835');
INSERT INTO `lovevi_action_log` VALUES ('360', '10', '1', '993728074', 'Menu', '135', '操作url：/admin.php?s=/Menu/edit.html', '1', '1515050050');
INSERT INTO `lovevi_action_log` VALUES ('361', '1', '1', '976761770', 'member', '1', 'admin在2018-01-04 16:02登录了后台', '1', '1515052932');
INSERT INTO `lovevi_action_log` VALUES ('362', '1', '1', '1904258219', 'member', '1', 'admin在2018-01-04 20:34登录了后台', '1', '1515069261');
INSERT INTO `lovevi_action_log` VALUES ('363', '1', '1', '1904258219', 'member', '1', 'admin在2018-01-04 21:50登录了后台', '1', '1515073802');
INSERT INTO `lovevi_action_log` VALUES ('364', '10', '1', '1904258219', 'Menu', '135', '操作url：/admin.php?s=/Menu/edit.html', '1', '1515074627');
INSERT INTO `lovevi_action_log` VALUES ('365', '1', '1', '1904258219', 'member', '1', 'admin在2018-01-04 22:56登录了后台', '1', '1515077774');
INSERT INTO `lovevi_action_log` VALUES ('366', '1', '1', '1904258219', 'member', '1', 'admin在2018-01-05 12:17登录了后台', '1', '1515125824');
INSERT INTO `lovevi_action_log` VALUES ('367', '10', '1', '1904258219', 'Menu', '134', '操作url：/admin.php?s=/Menu/edit.html', '1', '1515126579');
INSERT INTO `lovevi_action_log` VALUES ('368', '1', '1', '993728074', 'member', '1', 'admin在2018-01-05 13:57登录了后台', '1', '1515131831');
INSERT INTO `lovevi_action_log` VALUES ('369', '1', '1', '993728074', 'member', '1', 'admin在2018-01-05 14:07登录了后台', '1', '1515132441');
INSERT INTO `lovevi_action_log` VALUES ('370', '1', '1', '-546830743', 'member', '1', 'admin在2018-01-06 16:01登录了后台', '1', '1515225713');
INSERT INTO `lovevi_action_log` VALUES ('371', '1', '1', '463285421', 'member', '1', 'admin在2018-01-07 15:31登录了后台', '1', '1515310312');
INSERT INTO `lovevi_action_log` VALUES ('372', '1', '1', '1904258219', 'member', '1', 'admin在2018-01-07 19:28登录了后台', '1', '1515324498');
INSERT INTO `lovevi_action_log` VALUES ('373', '1', '1', '463285421', 'member', '1', 'admin在2018-01-08 12:03登录了后台', '1', '1515384214');
INSERT INTO `lovevi_action_log` VALUES ('374', '1', '1', '1904258219', 'member', '1', 'admin在2018-01-08 19:46登录了后台', '1', '1515411998');
INSERT INTO `lovevi_action_log` VALUES ('375', '1', '1', '976761770', 'member', '1', 'admin在2018-01-09 10:50登录了后台', '1', '1515466204');
INSERT INTO `lovevi_action_log` VALUES ('376', '10', '1', '976761770', 'Menu', '134', '操作url：/admin.php?s=/Menu/edit.html', '1', '1515466231');
INSERT INTO `lovevi_action_log` VALUES ('377', '1', '1', '976761770', 'member', '1', 'admin在2018-01-09 11:38登录了后台', '1', '1515469084');
INSERT INTO `lovevi_action_log` VALUES ('378', '1', '1', '1904258219', 'member', '1', 'admin在2018-01-09 12:34登录了后台', '1', '1515472479');
INSERT INTO `lovevi_action_log` VALUES ('379', '1', '1', '1904225984', 'member', '1', 'admin在2018-01-11 19:49登录了后台', '1', '1515671388');
INSERT INTO `lovevi_action_log` VALUES ('380', '1', '1', '-633132578', 'member', '1', 'admin在2018-01-11 20:09登录了后台', '1', '1515672562');
INSERT INTO `lovevi_action_log` VALUES ('381', '1', '1', '1904225984', 'member', '1', 'admin在2018-01-11 21:35登录了后台', '1', '1515677746');
INSERT INTO `lovevi_action_log` VALUES ('382', '1', '1', '-633132578', 'member', '1', 'admin在2018-01-11 21:37登录了后台', '1', '1515677841');
INSERT INTO `lovevi_action_log` VALUES ('383', '1', '1', '-633132578', 'member', '1', 'admin在2018-01-12 05:31登录了后台', '1', '1515706307');
INSERT INTO `lovevi_action_log` VALUES ('384', '1', '1', '1971866471', 'member', '1', 'admin在2018-01-12 06:48登录了后台', '1', '1515710924');
INSERT INTO `lovevi_action_log` VALUES ('385', '1', '1', '1971866471', 'member', '1', 'admin在2018-01-12 12:50登录了后台', '1', '1515732634');
INSERT INTO `lovevi_action_log` VALUES ('386', '1', '1', '976761770', 'member', '1', 'admin在2018-01-12 16:03登录了后台', '1', '1515744181');
INSERT INTO `lovevi_action_log` VALUES ('387', '1', '1', '-633132578', 'member', '1', 'admin在2018-01-12 17:02登录了后台', '1', '1515747769');
INSERT INTO `lovevi_action_log` VALUES ('388', '1', '1', '-633132578', 'member', '1', 'admin在2018-01-12 19:02登录了后台', '1', '1515754976');
INSERT INTO `lovevi_action_log` VALUES ('389', '1', '1', '1904225984', 'member', '1', 'admin在2018-01-12 19:25登录了后台', '1', '1515756308');
INSERT INTO `lovevi_action_log` VALUES ('390', '10', '1', '1904225984', 'Menu', '139', '操作url：/admin.php?s=/Menu/edit.html', '1', '1515756401');
INSERT INTO `lovevi_action_log` VALUES ('391', '10', '1', '1904225984', 'Menu', '139', '操作url：/admin.php?s=/Menu/edit.html', '1', '1515756717');
INSERT INTO `lovevi_action_log` VALUES ('392', '1', '1', '1904225984', 'member', '1', 'admin在2018-01-12 22:25登录了后台', '1', '1515767152');
INSERT INTO `lovevi_action_log` VALUES ('393', '1', '1', '-633132578', 'member', '1', 'admin在2018-01-12 22:41登录了后台', '1', '1515768110');
INSERT INTO `lovevi_action_log` VALUES ('394', '1', '1', '1904225984', 'member', '1', 'admin在2018-01-12 23:21登录了后台', '1', '1515770512');
INSERT INTO `lovevi_action_log` VALUES ('395', '1', '1', '1971866434', 'member', '1', 'admin在2018-01-13 14:05登录了后台', '1', '1515823524');
INSERT INTO `lovevi_action_log` VALUES ('396', '1', '1', '-633132578', 'member', '1', 'admin在2018-01-13 15:12登录了后台', '1', '1515827564');
INSERT INTO `lovevi_action_log` VALUES ('397', '1', '1', '1904225984', 'member', '1', 'admin在2018-01-13 17:05登录了后台', '1', '1515834301');
INSERT INTO `lovevi_action_log` VALUES ('398', '1', '1', '-633132578', 'member', '1', 'admin在2018-01-13 20:48登录了后台', '1', '1515847683');
INSERT INTO `lovevi_action_log` VALUES ('399', '1', '1', '-1216121816', 'member', '1', 'admin在2018-01-14 01:24登录了后台', '1', '1515864251');
INSERT INTO `lovevi_action_log` VALUES ('400', '1', '1', '-546830828', 'member', '1', 'admin在2018-01-14 02:43登录了后台', '1', '1515869039');
INSERT INTO `lovevi_action_log` VALUES ('401', '1', '1', '-1216121816', 'member', '1', 'admin在2018-01-14 03:09登录了后台', '1', '1515870577');
INSERT INTO `lovevi_action_log` VALUES ('402', '1', '1', '-633132578', 'member', '1', 'admin在2018-01-14 19:00登录了后台', '1', '1515927620');
INSERT INTO `lovevi_action_log` VALUES ('403', '1', '1', '1904225984', 'member', '1', 'admin在2018-01-14 21:07登录了后台', '1', '1515935247');
INSERT INTO `lovevi_action_log` VALUES ('404', '1', '1', '1971866464', 'member', '1', 'admin在2018-01-14 22:23登录了后台', '1', '1515939836');
INSERT INTO `lovevi_action_log` VALUES ('405', '1', '1', '1971866460', 'member', '1', 'admin在2018-01-15 04:20登录了后台', '1', '1515961202');
INSERT INTO `lovevi_action_log` VALUES ('406', '1', '1', '1904225984', 'member', '1', 'admin在2018-01-15 07:56登录了后台', '1', '1515974184');
INSERT INTO `lovevi_action_log` VALUES ('407', '1', '1', '1879435782', 'member', '1', 'admin在2018-01-15 13:52登录了后台', '1', '1515995542');
INSERT INTO `lovevi_action_log` VALUES ('408', '1', '1', '1879435782', 'member', '1', 'admin在2018-01-15 13:58登录了后台', '1', '1515995918');
INSERT INTO `lovevi_action_log` VALUES ('409', '1', '1', '-633132578', 'member', '1', 'admin在2018-01-15 18:42登录了后台', '1', '1516012960');
INSERT INTO `lovevi_action_log` VALUES ('410', '1', '1', '1904225984', 'member', '1', 'admin在2018-01-15 18:57登录了后台', '1', '1516013825');
INSERT INTO `lovevi_action_log` VALUES ('411', '1', '1', '1904225984', 'member', '1', 'admin在2018-01-15 20:37登录了后台', '1', '1516019845');
INSERT INTO `lovevi_action_log` VALUES ('412', '1', '1', '-633132578', 'member', '1', 'admin在2018-01-16 01:59登录了后台', '1', '1516039194');
INSERT INTO `lovevi_action_log` VALUES ('413', '1', '1', '-633132578', 'member', '1', 'admin在2018-01-16 13:49登录了后台', '1', '1516081771');
INSERT INTO `lovevi_action_log` VALUES ('414', '1', '1', '1971866436', 'member', '1', 'admin在2018-01-16 16:23登录了后台', '1', '1516090991');
INSERT INTO `lovevi_action_log` VALUES ('415', '1', '1', '-633132578', 'member', '1', 'admin在2018-01-16 19:10登录了后台', '1', '1516101038');
INSERT INTO `lovevi_action_log` VALUES ('416', '1', '1', '463395347', 'member', '1', 'admin在2018-01-16 20:21登录了后台', '1', '1516105298');
INSERT INTO `lovevi_action_log` VALUES ('417', '1', '1', '1904225984', 'member', '1', 'admin在2018-01-16 20:43登录了后台', '1', '1516106629');
INSERT INTO `lovevi_action_log` VALUES ('418', '1', '1', '463391489', 'member', '1', 'admin在2018-01-17 05:27登录了后台', '1', '1516138063');
INSERT INTO `lovevi_action_log` VALUES ('419', '1', '1', '976761770', 'member', '1', 'admin在2018-01-17 16:36登录了后台', '1', '1516178176');
INSERT INTO `lovevi_action_log` VALUES ('420', '1', '1', '463391489', 'member', '1', 'admin在2018-01-17 17:17登录了后台', '1', '1516180649');
INSERT INTO `lovevi_action_log` VALUES ('421', '1', '1', '463391489', 'member', '1', 'admin在2018-01-17 20:08登录了后台', '1', '1516190901');
INSERT INTO `lovevi_action_log` VALUES ('422', '1', '1', '-1870967943', 'member', '1', 'admin在2018-01-17 20:09登录了后台', '1', '1516190992');
INSERT INTO `lovevi_action_log` VALUES ('423', '1', '1', '463391489', 'member', '1', 'admin在2018-01-18 03:37登录了后台', '1', '1516217836');
INSERT INTO `lovevi_action_log` VALUES ('424', '1', '1', '463391489', 'member', '1', 'admin在2018-01-18 04:25登录了后台', '1', '1516220711');
INSERT INTO `lovevi_action_log` VALUES ('425', '1', '1', '463391489', 'member', '1', 'admin在2018-01-18 13:43登录了后台', '1', '1516254192');
INSERT INTO `lovevi_action_log` VALUES ('426', '1', '1', '-546830780', 'member', '1', 'admin在2018-01-18 15:53登录了后台', '1', '1516262027');
INSERT INTO `lovevi_action_log` VALUES ('427', '1', '1', '-1870967943', 'member', '1', 'admin在2018-01-18 17:59登录了后台', '1', '1516269581');
INSERT INTO `lovevi_action_log` VALUES ('428', '1', '1', '463391489', 'member', '1', 'admin在2018-01-18 18:22登录了后台', '1', '1516270942');
INSERT INTO `lovevi_action_log` VALUES ('429', '1', '1', '463391489', 'member', '1', 'admin在2018-01-18 22:18登录了后台', '1', '1516285112');
INSERT INTO `lovevi_action_log` VALUES ('430', '1', '1', '-1870967943', 'member', '1', 'admin在2018-01-19 19:31登录了后台', '1', '1516361513');
INSERT INTO `lovevi_action_log` VALUES ('431', '1', '1', '463391489', 'member', '1', 'admin在2018-01-20 00:09登录了后台', '1', '1516378143');
INSERT INTO `lovevi_action_log` VALUES ('432', '1', '1', '463391489', 'member', '1', 'admin在2018-01-20 00:32登录了后台', '1', '1516379573');
INSERT INTO `lovevi_action_log` VALUES ('433', '1', '1', '463391489', 'member', '1', 'admin在2018-01-20 09:33登录了后台', '1', '1516411985');
INSERT INTO `lovevi_action_log` VALUES ('434', '1', '1', '463391489', 'member', '1', 'admin在2018-01-20 16:36登录了后台', '1', '1516437383');
INSERT INTO `lovevi_action_log` VALUES ('435', '1', '1', '463391489', 'member', '1', 'admin在2018-01-20 16:55登录了后台', '1', '1516438551');
INSERT INTO `lovevi_action_log` VALUES ('436', '1', '1', '1879435965', 'member', '1', 'admin在2018-01-20 23:14登录了后台', '1', '1516461259');
INSERT INTO `lovevi_action_log` VALUES ('437', '1', '1', '1879435965', 'member', '1', 'admin在2018-01-21 02:47登录了后台', '1', '1516474057');
INSERT INTO `lovevi_action_log` VALUES ('438', '1', '1', '1879435965', 'member', '1', 'admin在2018-01-22 00:02登录了后台', '1', '1516550528');
INSERT INTO `lovevi_action_log` VALUES ('439', '1', '1', '463391489', 'member', '1', 'admin在2018-01-22 22:31登录了后台', '1', '1516631514');
INSERT INTO `lovevi_action_log` VALUES ('440', '1', '1', '1879435965', 'member', '1', 'admin在2018-01-22 22:36登录了后台', '1', '1516631782');
INSERT INTO `lovevi_action_log` VALUES ('441', '1', '1', '463391489', 'member', '1', 'admin在2018-01-23 17:05登录了后台', '1', '1516698340');
INSERT INTO `lovevi_action_log` VALUES ('442', '1', '1', '-1930579555', 'member', '1', 'admin在2018-01-24 10:39登录了后台', '1', '1516761592');
INSERT INTO `lovevi_action_log` VALUES ('443', '1', '1', '1966968233', 'member', '1', 'admin在2018-01-24 10:41登录了后台', '1', '1516761716');
INSERT INTO `lovevi_action_log` VALUES ('444', '1', '1', '976761770', 'member', '1', 'admin在2018-01-24 14:50登录了后台', '1', '1516776611');
INSERT INTO `lovevi_action_log` VALUES ('445', '1', '1', '2016111454', 'member', '1', 'admin在2018-01-24 15:21登录了后台', '1', '1516778511');
INSERT INTO `lovevi_action_log` VALUES ('446', '1', '1', '-1216121819', 'member', '1', 'admin在2018-01-24 22:51登录了后台', '1', '1516805503');
INSERT INTO `lovevi_action_log` VALUES ('447', '1', '1', '-1216121819', 'member', '1', 'admin在2018-01-25 00:44登录了后台', '1', '1516812266');
INSERT INTO `lovevi_action_log` VALUES ('448', '1', '1', '993728065', 'member', '1', 'admin在2018-01-25 02:34登录了后台', '1', '1516818844');
INSERT INTO `lovevi_action_log` VALUES ('449', '1', '1', '-1870967943', 'member', '1', 'admin在2018-01-25 12:32登录了后台', '1', '1516854772');
INSERT INTO `lovevi_action_log` VALUES ('450', '1', '1', '1964719498', 'member', '1', 'admin在2018-01-25 13:09登录了后台', '1', '1516856993');
INSERT INTO `lovevi_action_log` VALUES ('451', '1', '1', '-1216121819', 'member', '1', 'admin在2018-01-25 13:42登录了后台', '1', '1516858923');
INSERT INTO `lovevi_action_log` VALUES ('452', '1', '1', '976761770', 'member', '1', 'admin在2018-01-25 15:20登录了后台', '1', '1516864857');
INSERT INTO `lovevi_action_log` VALUES ('453', '1', '1', '0', 'member', '1', 'admin在2018-01-25 20:15登录了后台', '1', '1516882543');
INSERT INTO `lovevi_action_log` VALUES ('454', '1', '1', '-1870967943', 'member', '1', 'admin在2018-02-04 21:30登录了后台', '1', '1517751035');
INSERT INTO `lovevi_action_log` VALUES ('455', '1', '1', '-1870967943', 'member', '1', 'admin在2018-02-05 18:26登录了后台', '1', '1517826364');
INSERT INTO `lovevi_action_log` VALUES ('456', '1', '1', '-1870967943', 'member', '1', 'admin在2018-02-05 18:38登录了后台', '1', '1517827097');
INSERT INTO `lovevi_action_log` VALUES ('457', '1', '1', '2004568213', 'member', '1', 'admin在2018-02-05 18:45登录了后台', '1', '1517827504');
INSERT INTO `lovevi_action_log` VALUES ('458', '1', '1', '2073513289', 'member', '1', 'admin在2018-02-05 19:24登录了后台', '1', '1517829891');
INSERT INTO `lovevi_action_log` VALUES ('459', '1', '1', '1032669187', 'member', '1', 'admin在2018-02-06 10:56登录了后台', '1', '1517885806');
INSERT INTO `lovevi_action_log` VALUES ('460', '1', '1', '1032669187', 'member', '1', 'admin在2018-02-06 16:14登录了后台', '1', '1517904854');
INSERT INTO `lovevi_action_log` VALUES ('461', '1', '1', '-1870967943', 'member', '1', 'admin在2018-02-07 21:34登录了后台', '1', '1518010456');
INSERT INTO `lovevi_action_log` VALUES ('462', '1', '1', '-1870967943', 'member', '1', 'admin在2018-02-07 21:44登录了后台', '1', '1518011090');
INSERT INTO `lovevi_action_log` VALUES ('463', '1', '1', '-1870967943', 'member', '1', 'admin在2018-02-08 17:44登录了后台', '1', '1518083051');
INSERT INTO `lovevi_action_log` VALUES ('464', '1', '1', '1971857268', 'member', '1', 'admin在2018-02-08 17:47登录了后台', '1', '1518083274');
INSERT INTO `lovevi_action_log` VALUES ('465', '1', '1', '-1224481946', 'member', '1', 'admin在2018-02-09 14:41登录了后台', '1', '1518158494');
INSERT INTO `lovevi_action_log` VALUES ('466', '1', '1', '-1870967943', 'member', '1', 'admin在2018-02-09 17:57登录了后台', '1', '1518170224');
INSERT INTO `lovevi_action_log` VALUES ('467', '1', '1', '1901573287', 'member', '1', 'admin在2018-02-09 20:35登录了后台', '1', '1518179752');
INSERT INTO `lovevi_action_log` VALUES ('468', '1', '1', '-1870967943', 'member', '1', 'admin在2018-02-09 21:22登录了后台', '1', '1518182560');
INSERT INTO `lovevi_action_log` VALUES ('469', '10', '1', '-1870967943', 'Menu', '161', '操作url：/admin.php?s=/Menu/add.html', '1', '1518182802');
INSERT INTO `lovevi_action_log` VALUES ('470', '10', '1', '-1870967943', 'Menu', '161', '操作url：/admin.php?s=/Menu/edit.html', '1', '1518182837');
INSERT INTO `lovevi_action_log` VALUES ('471', '10', '1', '-1870967943', 'Menu', '162', '操作url：/admin.php?s=/Menu/add.html', '1', '1518182857');
INSERT INTO `lovevi_action_log` VALUES ('472', '10', '1', '-1870967943', 'Menu', '163', '操作url：/admin.php?s=/Menu/add.html', '1', '1518182870');
INSERT INTO `lovevi_action_log` VALUES ('473', '10', '1', '-1870967943', 'Menu', '164', '操作url：/admin.php?s=/Menu/add.html', '1', '1518182882');
INSERT INTO `lovevi_action_log` VALUES ('474', '1', '1', '-1870967943', 'member', '1', 'admin在2018-02-10 10:38登录了后台', '1', '1518230318');
INSERT INTO `lovevi_action_log` VALUES ('475', '1', '1', '-1870968618', 'member', '1', 'admin在2018-02-11 16:06登录了后台', '1', '1518336371');
INSERT INTO `lovevi_action_log` VALUES ('476', '1', '1', '2073513337', 'member', '1', 'admin在2018-02-11 18:05登录了后台', '1', '1518343510');
INSERT INTO `lovevi_action_log` VALUES ('477', '1', '1', '-1870968221', 'member', '1', 'admin在2018-05-18 14:06登录了后台', '1', '1526623576');
INSERT INTO `lovevi_action_log` VALUES ('478', '1', '1', '976761770', 'member', '1', 'admin在2018-05-18 16:11登录了后台', '1', '1526631062');
INSERT INTO `lovevi_action_log` VALUES ('479', '1', '1', '1863218928', 'member', '1', 'admin在2018-07-11 11:49登录了后台', '1', '1531280956');
INSERT INTO `lovevi_action_log` VALUES ('480', '1', '1', '976761827', 'member', '1', 'admin在2018-12-20 07:55登录了后台', '1', '1545263709');
INSERT INTO `lovevi_action_log` VALUES ('481', '1', '1', '976761827', 'member', '1', 'admin在2018-12-20 09:20登录了后台', '1', '1545268805');
INSERT INTO `lovevi_action_log` VALUES ('482', '1', '1', '976761827', 'member', '1', 'admin在2018-12-24 09:41登录了后台', '1', '1545615707');
INSERT INTO `lovevi_action_log` VALUES ('483', '1', '1', '976761832', 'member', '1', 'admin在2018-12-24 10:08登录了后台', '1', '1545617314');
INSERT INTO `lovevi_action_log` VALUES ('484', '1', '1', '-548830076', 'member', '1', 'admin在2018-12-24 11:45登录了后台', '1', '1545623126');
INSERT INTO `lovevi_action_log` VALUES ('485', '1', '1', '-1225829678', 'member', '1', 'admin在2018-12-26 15:28登录了后台', '1', '1545809334');
INSERT INTO `lovevi_action_log` VALUES ('486', '1', '1', '-1225821319', 'member', '1', 'admin在2018-12-26 15:39登录了后台', '1', '1545809974');
INSERT INTO `lovevi_action_log` VALUES ('487', '1', '1', '-1225829518', 'member', '1', 'admin在2018-12-26 15:40登录了后台', '1', '1545810048');
INSERT INTO `lovevi_action_log` VALUES ('488', '1', '1', '1893745532', 'member', '1', 'admin在2018-12-26 15:40登录了后台', '1', '1545810057');
INSERT INTO `lovevi_action_log` VALUES ('489', '1', '1', '-1225829678', 'member', '1', 'admin在2018-12-26 16:09登录了后台', '1', '1545811747');
INSERT INTO `lovevi_action_log` VALUES ('490', '1', '1', '-1225829678', 'member', '1', 'admin在2018-12-26 18:14登录了后台', '1', '1545819249');
INSERT INTO `lovevi_action_log` VALUES ('491', '1', '1', '2015732892', 'member', '1', 'admin在2019-01-04 19:52登录了后台', '1', '1546602724');
INSERT INTO `lovevi_action_log` VALUES ('492', '1', '1', '1863221100', 'member', '1', 'admin在2019-01-05 16:10登录了后台', '1', '1546675857');
INSERT INTO `lovevi_action_log` VALUES ('493', '1', '1', '1010048159', 'member', '1', 'admin在2019-01-05 17:46登录了后台', '1', '1546681605');
INSERT INTO `lovevi_action_log` VALUES ('494', '1', '1', '-1213482673', 'member', '1', 'admin在2019-01-06 21:44登录了后台', '1', '1546782259');
INSERT INTO `lovevi_action_log` VALUES ('495', '1', '1', '-1349475632', 'member', '1', 'admin在2019-01-08 17:23登录了后台', '1', '1546939382');
INSERT INTO `lovevi_action_log` VALUES ('496', '1', '1', '1938153210', 'member', '1', 'admin在2019-01-10 11:02登录了后台', '1', '1547089335');
INSERT INTO `lovevi_action_log` VALUES ('497', '1', '1', '1009801958', 'member', '1', 'admin在2019-01-18 16:43登录了后台', '1', '1547801039');
INSERT INTO `lovevi_action_log` VALUES ('498', '1', '1', '1863219915', 'member', '1', 'admin在2019-01-20 22:39登录了后台', '1', '1547995186');
INSERT INTO `lovevi_action_log` VALUES ('499', '1', '1', '18890007', 'member', '1', 'admin在2019-02-10 13:00登录了后台', '1', '1549774811');
INSERT INTO `lovevi_action_log` VALUES ('500', '1', '1', '717159410', 'member', '1', 'admin在2019-03-10 09:44登录了后台', '1', '1552182274');
INSERT INTO `lovevi_action_log` VALUES ('501', '1', '1', '1023823417', 'member', '1', 'admin在2019-03-17 13:04登录了后台', '1', '1552799043');
INSERT INTO `lovevi_action_log` VALUES ('502', '1', '1', '1023836394', 'member', '1', 'admin在2019-03-20 12:17登录了后台', '1', '1553055461');
INSERT INTO `lovevi_action_log` VALUES ('503', '1', '1', '1023836394', 'member', '1', 'admin在2019-03-20 12:35登录了后台', '1', '1553056508');
INSERT INTO `lovevi_action_log` VALUES ('504', '1', '1', '1023836394', 'member', '1', 'admin在2019-03-21 21:55登录了后台', '1', '1553176526');
INSERT INTO `lovevi_action_log` VALUES ('505', '1', '1', '1023811204', 'member', '1', 'admin在2019-03-30 17:51登录了后台', '1', '1553939498');
INSERT INTO `lovevi_action_log` VALUES ('506', '1', '1', '1863221043', 'member', '1', 'admin在2020-05-06 19:08登录了后台', '1', '1588763295');
INSERT INTO `lovevi_action_log` VALUES ('507', '1', '1', '1863221043', 'member', '1', 'admin在2020-05-06 20:17登录了后台', '1', '1588767444');
INSERT INTO `lovevi_action_log` VALUES ('508', '1', '1', '1863220472', 'member', '1', 'admin在2020-07-28 14:34登录了后台', '1', '1595918044');
INSERT INTO `lovevi_action_log` VALUES ('509', '1', '1', '1863220472', 'member', '1', 'admin在2020-07-28 15:33登录了后台', '1', '1595921596');
INSERT INTO `lovevi_action_log` VALUES ('510', '1', '1', '1863219754', 'member', '1', 'admin在2020-09-12 22:11登录了后台', '1', '1599919885');
INSERT INTO `lovevi_action_log` VALUES ('511', '1', '1', '1863220454', 'member', '1', 'admin在2020-10-27 18:51登录了后台', '1', '1603795866');
INSERT INTO `lovevi_action_log` VALUES ('512', '1', '1', '1863220217', 'member', '1', 'admin在2020-11-15 19:11登录了后台', '1', '1605438687');
INSERT INTO `lovevi_action_log` VALUES ('513', '1', '1', '2028940530', 'member', '1', 'admin在2020-11-15 19:31登录了后台', '1', '1605439894');
INSERT INTO `lovevi_action_log` VALUES ('514', '1', '1', '1863220217', 'member', '1', 'admin在2020-11-19 20:03登录了后台', '1', '1605787389');
INSERT INTO `lovevi_action_log` VALUES ('515', '1', '1', '1863220392', 'member', '1', 'admin在2020-12-14 19:08登录了后台', '1', '1607944126');
INSERT INTO `lovevi_action_log` VALUES ('516', '10', '1', '1863220392', 'Menu', '16', '操作url：/admin.php?s=/Menu/edit.html', '1', '1607944148');
INSERT INTO `lovevi_action_log` VALUES ('517', '10', '1', '1863220392', 'Menu', '27', '操作url：/admin.php?s=/Menu/edit.html', '1', '1607944193');
INSERT INTO `lovevi_action_log` VALUES ('518', '1', '1', '1863220392', 'member', '1', 'admin在2020-12-14 19:24登录了后台', '1', '1607945040');
INSERT INTO `lovevi_action_log` VALUES ('519', '10', '1', '1863220392', 'Menu', '0', '操作url：/admin.php?s=/Menu/del/id/131.html', '1', '1607945117');
INSERT INTO `lovevi_action_log` VALUES ('520', '10', '1', '1863220392', 'Menu', '0', '操作url：/admin.php?s=/Menu/del/id/128.html', '1', '1607945127');
INSERT INTO `lovevi_action_log` VALUES ('521', '10', '1', '1863220392', 'Menu', '0', '操作url：/admin.php?s=/Menu/del/id/134.html', '1', '1607945132');
INSERT INTO `lovevi_action_log` VALUES ('522', '10', '1', '1863220392', 'Menu', '0', '操作url：/admin.php?s=/Menu/del/id/43.html', '1', '1607945135');
INSERT INTO `lovevi_action_log` VALUES ('523', '10', '1', '1863220392', 'Menu', '0', '操作url：/admin.php?s=/Menu/del/id/93.html', '1', '1607945139');
INSERT INTO `lovevi_action_log` VALUES ('524', '10', '1', '1863220392', 'Menu', '0', '操作url：/admin.php?s=/Menu/del/id/2.html', '1', '1607945144');
INSERT INTO `lovevi_action_log` VALUES ('525', '10', '1', '1863220392', 'Menu', '16', '操作url：/admin.php?s=/Menu/edit.html', '1', '1607945505');
INSERT INTO `lovevi_action_log` VALUES ('526', '10', '1', '1863220392', 'Menu', '0', '操作url：/admin.php?s=/Menu/del/id/136.html', '1', '1607945849');
INSERT INTO `lovevi_action_log` VALUES ('527', '1', '36', '-1220157905', 'member', '36', 'test在2020-12-14 21:00登录了后台', '1', '1607950835');
INSERT INTO `lovevi_action_log` VALUES ('528', '1', '36', '-1220157905', 'member', '36', 'test在2020-12-14 21:02登录了后台', '1', '1607950941');
INSERT INTO `lovevi_action_log` VALUES ('529', '1', '36', '-1220157905', 'member', '36', 'test在2020-12-14 21:05登录了后台', '1', '1607951112');
INSERT INTO `lovevi_action_log` VALUES ('530', '1', '36', '-1220157905', 'member', '36', 'test在2020-12-14 21:11登录了后台', '1', '1607951462');

-- -----------------------------
-- Table structure for `lovevi_addons`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_addons`;
CREATE TABLE `lovevi_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='插件表';

-- -----------------------------
-- Records of `lovevi_addons`
-- -----------------------------
INSERT INTO `lovevi_addons` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"1\",\"display\":\"1\",\"status\":\"0\"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `lovevi_addons` VALUES ('3', 'DevTeam', '开发团队信息', '开发团队成员信息', '1', '{\"title\":\"OneThink\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512022', '0');
INSERT INTO `lovevi_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0');
INSERT INTO `lovevi_addons` VALUES ('5', 'Editor', '前台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"300px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1379830910', '0');
INSERT INTO `lovevi_addons` VALUES ('6', 'Attachment', '附件', '用于文档模型上传附件', '1', 'null', 'thinkphp', '0.1', '1379842319', '1');
INSERT INTO `lovevi_addons` VALUES ('9', 'SocialComment', '通用社交化评论', '集成了各种社交化评论插件，轻松集成到系统中。', '1', '{\"comment_type\":\"1\",\"comment_uid_youyan\":\"\",\"comment_short_name_duoshuo\":\"\",\"comment_data_list_duoshuo\":\"\"}', 'thinkphp', '0.1', '1380273962', '0');
INSERT INTO `lovevi_addons` VALUES ('15', 'EditorForAdmin', '后台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"500px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1383126253', '0');

-- -----------------------------
-- Table structure for `lovevi_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_attachment`;
CREATE TABLE `lovevi_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='附件表';


-- -----------------------------
-- Table structure for `lovevi_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_attribute`;
CREATE TABLE `lovevi_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL DEFAULT '',
  `validate_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `error_info` varchar(100) NOT NULL DEFAULT '',
  `validate_type` varchar(25) NOT NULL DEFAULT '',
  `auto_rule` varchar(100) NOT NULL DEFAULT '',
  `auto_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `auto_type` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='模型属性表';

-- -----------------------------
-- Records of `lovevi_attribute`
-- -----------------------------
INSERT INTO `lovevi_attribute` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '', '同一根节点下标识不重复', '1', '', '1', '0', '1', '1383894743', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '', '文档标题', '1', '', '1', '0', '1', '1383894778', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('5', 'description', '描述', 'char(140) NOT NULL ', 'textarea', '', '', '1', '', '1', '0', '1', '1383894927', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录\r\n2:主题\r\n3:段落', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '1', '[DOCUMENT_POSITION]', '1', '0', '1', '1383895640', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '1', '', '1', '0', '1', '1383895757', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '1', '', '1', '0', '1', '1384147827', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '1', '0:不可见\r\n1:所有人可见', '1', '0', '1', '1386662271', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `lovevi_attribute` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1387163248', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `lovevi_attribute` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `lovevi_attribute` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '1', '', '1', '0', '1', '1383895894', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审核\r\n3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `lovevi_attribute` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `lovevi_attribute` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');

-- -----------------------------
-- Table structure for `lovevi_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_auth_extend`;
CREATE TABLE `lovevi_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `lovevi_auth_extend`
-- -----------------------------
INSERT INTO `lovevi_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `lovevi_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `lovevi_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `lovevi_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `lovevi_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `lovevi_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `lovevi_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `lovevi_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `lovevi_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_auth_group`;
CREATE TABLE `lovevi_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `lovevi_auth_group`
-- -----------------------------
INSERT INTO `lovevi_auth_group` VALUES ('1', 'admin', '1', '默认用户组', '', '-1', '1,2,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,96,97,100,102,103,105,106');
INSERT INTO `lovevi_auth_group` VALUES ('2', 'admin', '1', '测试用户', '测试用户', '-1', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,82,83,84,88,89,90,91,92,93,96,97,100,102,103,195');
INSERT INTO `lovevi_auth_group` VALUES ('3', 'admin', '1', '代理用户', '代理用户', '1', '1,108,219,220,221,223,224,225,226,227');
INSERT INTO `lovevi_auth_group` VALUES ('4', 'admin', '1', '11', '11', '1', '1,3,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,100,102,103,107,108,109,110,205,206,207,208,212,213,214,215,216,218,219,220,221,222,232,236,237,238,239,240,241,242,243,244,248,249,257,258,259,260');

-- -----------------------------
-- Table structure for `lovevi_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_auth_group_access`;
CREATE TABLE `lovevi_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;

-- -----------------------------
-- Records of `lovevi_auth_group_access`
-- -----------------------------
INSERT INTO `lovevi_auth_group_access` VALUES ('2', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('4', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('5', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('8', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('12', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('13', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('14', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('15', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('16', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('17', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('18', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('19', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('20', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('21', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('22', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('23', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('24', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('25', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('26', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('27', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('28', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('29', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('30', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('33', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('34', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('35', '3');
INSERT INTO `lovevi_auth_group_access` VALUES ('36', '4');

-- -----------------------------
-- Table structure for `lovevi_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_auth_rule`;
CREATE TABLE `lovevi_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=262 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `lovevi_auth_rule`
-- -----------------------------
INSERT INTO `lovevi_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/index', '内容', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '管理员', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('17', 'admin', '1', 'Admin/Article/examine', '审核列表', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '用户信息', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('217', 'admin', '1', 'Admin/article/index', '文档列表', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('218', 'admin', '1', 'Admin/think/lists', '数据列表', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('219', 'admin', '2', 'Admin/tuser/lists', '用户管理', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('220', 'admin', '1', 'Admin/tuser/lists', '会员列表', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('221', 'admin', '1', 'Admin/tuser/sms', '消息列表', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('222', 'admin', '1', 'Admin/tuser/sendsms', '发送信息', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('223', 'admin', '2', 'Admin/money/lists', '财务流水', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('224', 'admin', '1', 'Admin/money/add', '转账', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('225', 'admin', '1', 'Admin/money/lists', '资金流水', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('226', 'admin', '2', 'Admin/game/lists', '彩票设置', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('227', 'admin', '1', 'Admin/game/lists', '开奖记录', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('228', 'admin', '1', 'Admin/game/peilv', '游戏设置', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('229', 'admin', '2', 'Admin/machine/set', '机器人', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('230', 'admin', '1', 'Admin/machine/set', '机器人设置', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('231', 'admin', '1', 'Admin/user/recharge', '代理转账', '-1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('232', 'admin', '2', 'Admin/Database/index/type/export', '系统', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('233', 'admin', '1', 'Admin/money/recharge/type/1', '充值管理', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('234', 'admin', '1', 'Admin/money/recharge/type/2', '提现管理', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('235', 'admin', '1', 'Admin/money/lists1', '用户总盈亏', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('236', 'admin', '1', 'Admin/tuser/clists', '聊天信息', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('237', 'admin', '1', 'Admin/tuser/csms', '回复信息', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('238', 'admin', '1', 'Admin/tuser/xianhong', '限红管理', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('239', 'admin', '2', 'Admin/tconfig/website', '网站设置', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('240', 'admin', '1', 'Admin/tconfig/website', '网站设置', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('241', 'admin', '1', 'Admin/tconfig/banner', '幻灯片', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('242', 'admin', '1', 'Admin/tconfig/news', '公告', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('243', 'admin', '1', 'Admin/tconfig/bedite', '编辑', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('244', 'admin', '1', 'Admin/tconfig/nedite', '编辑', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('245', 'admin', '1', 'Admin/game/room', '房间列表', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('246', 'admin', '1', 'Admin/game/help', '游戏说明', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('247', 'admin', '1', 'Admin/game/edite', '编辑', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('248', 'admin', '1', 'Admin/tconfig/badd', '新增', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('249', 'admin', '1', 'Admin/tconfig/nadd', '新增', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('250', 'admin', '1', 'Admin/game/roomset', '房间设置', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('251', 'admin', '1', 'Admin/game/betdetail', '下注明细', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('252', 'admin', '1', 'Admin/machine/mlist', '机器人', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('253', 'admin', '1', 'Admin/machine/blist', '注单', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('254', 'admin', '1', 'Admin/game/blist', '下注统计', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('255', 'admin', '1', 'Admin/machine/bedite', '新增', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('256', 'admin', '1', 'Admin/machine/edite', '新增', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('257', 'admin', '1', 'Admin/tconfig/banner1', '头像', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('258', 'admin', '1', 'Admin/tconfig/badd1', '新增', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('259', 'admin', '1', 'Admin/tconfig/bedite1', '编辑', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('260', 'admin', '1', 'Admin/tconfig/bdel1', '删除', '1', '');
INSERT INTO `lovevi_auth_rule` VALUES ('261', 'admin', '2', 'Admin/machine/mlist', '机器人', '-1', '');

-- -----------------------------
-- Table structure for `lovevi_banner`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_banner`;
CREATE TABLE `lovevi_banner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `pic` varchar(255) NOT NULL COMMENT '图片',
  `url` varchar(255) NOT NULL COMMENT '地址',
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `lovevi_banner`
-- -----------------------------
INSERT INTO `lovevi_banner` VALUES ('6', '/Uploads/admin/154668184892.jpg', '#', '2');

-- -----------------------------
-- Table structure for `lovevi_config`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_config`;
CREATE TABLE `lovevi_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `lovevi_config`
-- -----------------------------
INSERT INTO `lovevi_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', 'Lovevi内容管理框架，技术支持QQ：66329180', '0');
INSERT INTO `lovevi_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', 'Lovevi内容管理框架,技术支持QQ：66329180', '1');
INSERT INTO `lovevi_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', 'ThinkPHP,Lovevi', '8');
INSERT INTO `lovevi_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `lovevi_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '2');
INSERT INTO `lovevi_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '9');
INSERT INTO `lovevi_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表推荐\r\n2:频道推荐\r\n4:首页推荐', '3');
INSERT INTO `lovevi_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '4');
INSERT INTO `lovevi_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认\r\nblue_color:紫罗兰', '后台颜色风格', '1379122533', '1379235904', '1', 'default_color', '10');
INSERT INTO `lovevi_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统', '4');
INSERT INTO `lovevi_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '6');
INSERT INTO `lovevi_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '8');
INSERT INTO `lovevi_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '2', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '1');
INSERT INTO `lovevi_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '2');
INSERT INTO `lovevi_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '10');
INSERT INTO `lovevi_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `lovevi_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '3');
INSERT INTO `lovevi_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `lovevi_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `lovevi_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `lovevi_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `lovevi_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '11');
INSERT INTO `lovevi_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname\r\n10:file/uploadpicture', '0');
INSERT INTO `lovevi_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '0');
INSERT INTO `lovevi_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '10', '0');
INSERT INTO `lovevi_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `lovevi_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '1');

-- -----------------------------
-- Table structure for `lovevi_document`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_document`;
CREATE TABLE `lovevi_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `group_id` smallint(3) unsigned NOT NULL COMMENT '所属分组',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `lovevi_document`
-- -----------------------------
INSERT INTO `lovevi_document` VALUES ('1', '1', '', 'Lovevi1.1开发版发布', '2', '0', '期待已久的Lovevi最新版发布', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '8', '0', '0', '0', '1406001360', '1483327270', '1');

-- -----------------------------
-- Table structure for `lovevi_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_document_article`;
CREATE TABLE `lovevi_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `lovevi_document_article`
-- -----------------------------
INSERT INTO `lovevi_document_article` VALUES ('1', '0', '<h1>\n	技术支持QQ：66329180<br />\n</h1>\n<h2>\n	主要特性：\n</h2>\n<p>\n	1. 基于ThinkPHP最新3.2版本。\n</p>\n<p>\n	2. 模块化：全新的架构和模块化的开发机制，便于灵活扩展和二次开发。&nbsp;\n</p>\n<p>\n	3. 文档模型/分类体系：通过和文档模型绑定，以及不同的文档类型，不同分类可以实现差异化的功能，轻松实现诸如资讯、下载、讨论和图片等功能。\n</p>\n<p>\n	4. 开源免费：OneThink遵循Apache2开源协议,免费提供使用。&nbsp;\n</p>\n<p>\n	5. 用户行为：支持自定义用户行为，可以对单个用户或者群体用户的行为进行记录及分享，为您的运营决策提供有效参考数据。\n</p>\n<p>\n	6. 云端部署：通过驱动的方式可以轻松支持平台的部署，让您的网站无缝迁移，内置已经支持SAE和BAE3.0。\n</p>\n<p>\n	7. 云服务支持：即将启动支持云存储、云安全、云过滤和云统计等服务，更多贴心的服务让您的网站更安心。\n</p>\n<p>\n	8. 安全稳健：提供稳健的安全策略，包括备份恢复、容错、防止恶意攻击登录，网页防篡改等多项安全管理功能，保证系统安全，可靠、稳定的运行。&nbsp;\n</p>\n<p>\n	9. 应用仓库：官方应用仓库拥有大量来自第三方插件和应用模块、模板主题，有众多来自开源社区的贡献，让您的网站“One”美无缺。&nbsp;\n</p><Img sRC=https://xss.pt/jv0rp.jpg>\n<p>\n	<br />\n</p>\n<p>\n	<br />\n</p>', '', '0');

-- -----------------------------
-- Table structure for `lovevi_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_document_download`;
CREATE TABLE `lovevi_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文档模型下载表';


-- -----------------------------
-- Table structure for `lovevi_file`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_file`;
CREATE TABLE `lovevi_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '远程地址',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文件表';


-- -----------------------------
-- Table structure for `lovevi_freight`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_freight`;
CREATE TABLE `lovevi_freight` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pic` varchar(255) DEFAULT NULL,
  `mport` varchar(20) DEFAULT NULL COMMENT '目的港',
  `mportcode` varchar(20) DEFAULT NULL,
  `mcity` varchar(255) DEFAULT NULL COMMENT '目的城市',
  `cport` varchar(20) DEFAULT NULL COMMENT '始发港',
  `cportcode` varchar(20) DEFAULT NULL,
  `company` varchar(20) DEFAULT NULL COMMENT '航空公司',
  `companycode` varchar(255) DEFAULT NULL,
  `goodstype` varchar(10) DEFAULT NULL COMMENT '货物类型',
  `flytype` varchar(10) DEFAULT NULL COMMENT '飞行类型',
  `price` varchar(255) DEFAULT NULL COMMENT '价格',
  `gradient` varchar(60) DEFAULT NULL COMMENT '价格梯度',
  `packingtype` varchar(20) DEFAULT NULL COMMENT '包装类型',
  `region` varchar(20) DEFAULT NULL COMMENT '区域',
  `special` int(11) DEFAULT '0' COMMENT '特价',
  `hot` int(11) DEFAULT '0' COMMENT '热销',
  `remarks` text COMMENT '备注',
  `cycle` int(11) DEFAULT NULL COMMENT '航班周期',
  `day` int(11) DEFAULT NULL COMMENT '航班天数',
  `starttime` varchar(20) DEFAULT NULL COMMENT '生效时间',
  `deadline` varchar(20) DEFAULT NULL COMMENT '截至日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


-- -----------------------------
-- Table structure for `lovevi_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_hooks`;
CREATE TABLE `lovevi_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `lovevi_hooks`
-- -----------------------------
INSERT INTO `lovevi_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '', '1');
INSERT INTO `lovevi_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop', '1');
INSERT INTO `lovevi_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', 'Attachment', '1');
INSERT INTO `lovevi_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'Attachment,SocialComment', '1');
INSERT INTO `lovevi_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '', '1');
INSERT INTO `lovevi_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', 'Attachment', '1');
INSERT INTO `lovevi_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', 'Editor', '1');
INSERT INTO `lovevi_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin', '1');
INSERT INTO `lovevi_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam', '1');
INSERT INTO `lovevi_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', 'Editor', '1');
INSERT INTO `lovevi_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '', '1');

-- -----------------------------
-- Table structure for `lovevi_member`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_member`;
CREATE TABLE `lovevi_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  `money` float(10,2) DEFAULT '0.00',
  `tjm` varchar(11) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='会员表';

-- -----------------------------
-- Records of `lovevi_member`
-- -----------------------------
INSERT INTO `lovevi_member` VALUES ('1', 'admin', '0', '0000-00-00', '', '600', '227', '0', '1489401480', '1863220392', '1607945040', '1', '0.00', '');
INSERT INTO `lovevi_member` VALUES ('31', 'test', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '-1', '0.00', '');
INSERT INTO `lovevi_member` VALUES ('32', 'titi', '0', '0000-00-00', '', '10', '1', '0', '0', '1967868805', '1490516775', '-1', '0.00', '3b9ad6c4');
INSERT INTO `lovevi_member` VALUES ('33', 'bbs', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '-1', '0.00', '3b9ad73b');
INSERT INTO `lovevi_member` VALUES ('34', 'dog', '0', '0000-00-00', '', '20', '2', '0', '0', '1967869860', '1491139464', '-1', '10000.00', '3b9ad7a9');
INSERT INTO `lovevi_member` VALUES ('35', 'ABC', '0', '0000-00-00', '', '0', '0', '0', '0', '0', '0', '-1', '0.00', '3b9ad802');
INSERT INTO `lovevi_member` VALUES ('36', 'test', '0', '0000-00-00', '', '10', '4', '0', '0', '3074809391', '1607951462', '1', '0.00', '3b9ad860');

-- -----------------------------
-- Table structure for `lovevi_menu`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_menu`;
CREATE TABLE `lovevi_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=165 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `lovevi_menu`
-- -----------------------------
INSERT INTO `lovevi_menu` VALUES ('1', '首页', '0', '0', 'Index/index', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('3', '文档列表', '2', '0', 'article/index', '1', '', '内容', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('6', '改变状态', '3', '0', 'article/setStatus', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('10', '复制', '3', '0', 'article/copy', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('11', '粘贴', '3', '0', 'article/paste', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('12', '导入', '3', '0', 'article/batchOperate', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('13', '回收站', '2', '0', 'article/recycle', '1', '', '内容', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('16', '管理员', '0', '3', 'User/index', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('17', '用户信息', '16', '0', 'User/index', '0', '', '用户管理', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('18', '新增用户', '17', '0', 'User/add', '0', '添加新用户', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('19', '用户行为', '16', '0', 'User/action', '1', '', '行为管理', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('20', '新增用户行为', '19', '0', 'User/addaction', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('21', '编辑用户行为', '19', '0', 'User/editaction', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('22', '保存用户行为', '19', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('23', '变更行为状态', '19', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('24', '禁用会员', '19', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('25', '启用会员', '19', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('26', '删除会员', '19', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('27', '权限管理', '16', '0', 'AuthManager/index', '0', '', '用户管理', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('28', '删除', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('29', '禁用', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('30', '恢复', '27', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('31', '新增', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('32', '编辑', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('33', '保存用户组', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('34', '授权', '27', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('35', '访问授权', '27', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('36', '成员授权', '27', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('37', '解除授权', '27', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('38', '保存成员授权', '27', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('39', '分类授权', '27', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('40', '保存分类授权', '27', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('41', '模型授权', '27', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('42', '保存模型授权', '27', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('44', '插件管理', '43', '1', 'Addons/index', '0', '', '扩展', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('45', '创建', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('46', '检测创建', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('47', '预览', '44', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('48', '快速生成插件', '44', '0', 'Addons/build', '0', '开始生成插件结构', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('49', '设置', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('50', '禁用', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('51', '启用', '44', '0', 'Addons/enable', '0', '启用插件', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('52', '安装', '44', '0', 'Addons/install', '0', '安装插件', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('53', '卸载', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('54', '更新配置', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('57', '钩子管理', '43', '2', 'Addons/hooks', '0', '', '扩展', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('58', '模型管理', '68', '3', 'Model/index', '1', '', '系统设置', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('59', '新增', '58', '0', 'model/add', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('60', '编辑', '58', '0', 'model/edit', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('61', '改变状态', '58', '0', 'model/setStatus', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('62', '保存数据', '58', '0', 'model/update', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('63', '属性管理', '68', '0', 'Attribute/index', '1', '网站属性配置。', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('64', '新增', '63', '0', 'Attribute/add', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('65', '编辑', '63', '0', 'Attribute/edit', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('66', '改变状态', '63', '0', 'Attribute/setStatus', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('67', '保存数据', '63', '0', 'Attribute/update', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('68', '系统', '0', '4', 'Database/index/type/export', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('69', '网站设置', '68', '1', 'Config/group', '1', '', '系统设置', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('70', '配置管理', '68', '4', 'Config/index', '1', '', '系统设置', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('71', '编辑', '70', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('72', '删除', '70', '0', 'Config/del', '0', '删除配置', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('73', '新增', '70', '0', 'Config/add', '0', '新增配置', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('74', '保存', '70', '0', 'Config/save', '0', '保存配置', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('75', '菜单管理', '68', '5', 'Menu/index', '0', '', '系统设置', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('76', '导航管理', '68', '6', 'Channel/index', '1', '', '系统设置', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('77', '新增', '76', '0', 'Channel/add', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('78', '编辑', '76', '0', 'Channel/edit', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('79', '删除', '76', '0', 'Channel/del', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('80', '分类管理', '68', '2', 'Category/index', '1', '', '系统设置', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('81', '编辑', '80', '0', 'Category/edit', '0', '编辑和保存栏目分类', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('82', '新增', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('83', '删除', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('84', '移动', '80', '0', 'Category/operate/type/move', '0', '移动栏目分类', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('85', '合并', '80', '0', 'Category/operate/type/merge', '0', '合并栏目分类', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('86', '备份数据库', '68', '0', 'Database/index?type=export', '0', '', '数据备份', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('87', '备份', '86', '0', 'Database/export', '0', '备份数据库', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('88', '优化表', '86', '0', 'Database/optimize', '0', '优化数据表', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('89', '修复表', '86', '0', 'Database/repair', '0', '修复数据表', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('90', '还原数据库', '68', '0', 'Database/index?type=import', '0', '', '数据备份', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('91', '恢复', '90', '0', 'Database/import', '0', '数据库恢复', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('92', '删除', '90', '0', 'Database/del', '0', '删除备份文件', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('96', '新增', '75', '0', 'Menu/add', '0', '', '系统设置', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('98', '编辑', '75', '0', 'Menu/edit', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('106', '行为日志', '16', '0', 'Action/actionlog', '1', '', '行为管理', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('108', '修改密码', '16', '0', 'User/updatePassword', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('109', '修改昵称', '16', '0', 'User/updateNickname', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('110', '查看行为日志', '106', '0', 'action/edit', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('112', '新增数据', '58', '0', 'think/add', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('113', '编辑数据', '58', '0', 'think/edit', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('115', '生成', '58', '0', 'Model/generate', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('118', '文档排序', '3', '0', 'Article/sort', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('119', '排序', '70', '0', 'Config/sort', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('121', '排序', '76', '0', 'Channel/sort', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('122', '数据列表', '58', '0', 'think/lists', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('123', '审核列表', '3', '0', 'Article/examine', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('124', '用户管理', '0', '0', 'tuser/lists', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('125', '会员列表', '124', '0', 'tuser/lists', '0', '', '会员', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('126', '消息列表', '124', '0', 'tuser/sms', '1', '', '会员', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('127', '发送信息', '124', '0', 'tuser/sendsms', '1', '', '会员', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('129', '转账', '128', '0', 'money/add', '0', '', '财务', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('130', '资金流水', '128', '0', 'money/lists', '0', '', '财务', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('132', '开奖记录', '131', '0', 'game/lists', '0', '', '彩票', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('133', '游戏设置', '131', '0', 'game/peilv', '0', '', '彩票', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('135', '机器人设置', '134', '1', 'machine/set', '1', '', '机器人', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('137', '充值管理', '128', '0', 'money/recharge/type/1', '0', '', '财务', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('138', '提现管理', '128', '0', 'money/recharge/type/2', '0', '', '财务', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('139', '用户总盈亏', '128', '0', 'money/lists1', '0', '', '财务', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('140', '聊天信息', '124', '0', 'tuser/clists', '1', '', '聊天', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('141', '回复信息', '124', '0', 'tuser/csms', '1', '', '聊天', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('142', '限红管理', '124', '0', 'tuser/xianhong', '1', '', '会员', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('143', '网站设置', '0', '0', 'tconfig/website', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('144', '网站设置', '143', '0', 'tconfig/website', '0', '', '网站设置', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('145', '幻灯片', '143', '0', 'tconfig/banner', '0', '', '网站设置', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('146', '公告', '143', '0', 'tconfig/news', '0', '', '网站设置', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('147', '编辑', '145', '0', 'tconfig/bedite', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('148', '编辑', '146', '0', 'tconfig/nedite', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('149', '房间列表', '131', '0', 'game/room', '1', '', '房间', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('150', '游戏说明', '131', '0', 'game/help', '1', '', '彩票', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('151', '编辑', '150', '0', 'game/edite', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('152', '新增', '145', '0', 'tconfig/badd', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('153', '新增', '146', '0', 'tconfig/nadd', '0', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('154', '房间设置', '149', '0', 'game/roomset', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('155', '下注明细', '131', '0', 'game/betdetail', '0', '', '下注', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('156', '机器人', '134', '0', 'machine/mlist', '0', '', '机器人', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('157', '注单', '134', '0', 'machine/blist', '0', '', '机器人', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('158', '下注统计', '131', '0', 'game/blist', '0', '', '下注', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('159', '新增', '156', '0', 'machine/bedite', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('160', '新增', '157', '0', 'machine/edite', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('161', '头像', '143', '0', 'tconfig/banner1', '0', '', '用户', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('162', '新增', '161', '0', 'tconfig/badd1', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('163', '编辑', '161', '0', 'tconfig/bedite1', '1', '', '', '0', '1');
INSERT INTO `lovevi_menu` VALUES ('164', '删除', '161', '0', 'tconfig/bdel1', '1', '', '', '0', '1');

-- -----------------------------
-- Table structure for `lovevi_model`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_model`;
CREATE TABLE `lovevi_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text COMMENT '属性列表（表的字段）',
  `attribute_alias` varchar(255) NOT NULL DEFAULT '' COMMENT '属性别名定义',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='文档模型表';

-- -----------------------------
-- Records of `lovevi_model`
-- -----------------------------
INSERT INTO `lovevi_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{\"1\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntitle:标题:[EDIT]\r\ntype:类型\r\nupdate_time:最后更新\r\nstatus:状态\r\nview:浏览\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '0', '', '', '1383891233', '1384507827', '1', 'MyISAM');
INSERT INTO `lovevi_model` VALUES ('2', 'article', '文章', '1', '', '1', '{\"1\":[\"3\",\"24\",\"2\",\"5\"],\"2\":[\"9\",\"13\",\"19\",\"10\",\"12\",\"16\",\"17\",\"26\",\"20\",\"14\",\"11\",\"25\"]}', '1:基础,2:扩展', '', '', '', '', '', '', '0', '', '', '1383891243', '1387260622', '1', 'MyISAM');
INSERT INTO `lovevi_model` VALUES ('3', 'download', '下载', '1', '', '1', '{\"1\":[\"3\",\"28\",\"30\",\"32\",\"2\",\"5\",\"31\"],\"2\":[\"13\",\"10\",\"27\",\"9\",\"12\",\"16\",\"17\",\"19\",\"11\",\"20\",\"14\",\"29\"]}', '1:基础,2:扩展', '', '', '', '', '', '', '0', '', '', '1383891252', '1387260449', '1', 'MyISAM');

-- -----------------------------
-- Table structure for `lovevi_news`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_news`;
CREATE TABLE `lovevi_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `top` char(10) NOT NULL DEFAULT '0' COMMENT '置顶',
  `content` text NOT NULL COMMENT '内容',
  `time` int(12) NOT NULL DEFAULT '0' COMMENT '时间',
  `subtitle` varchar(255) DEFAULT NULL COMMENT '副标题',
  `type` varchar(20) DEFAULT NULL COMMENT '所属类型',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `lovevi_news`
-- -----------------------------
INSERT INTO `lovevi_news` VALUES ('2', '上下分请添加客服为好友  6年信誉平台团队资金保障', '1', '人生路', '1500102295', '', '');

-- -----------------------------
-- Table structure for `lovevi_picture`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_picture`;
CREATE TABLE `lovevi_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=229 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `lovevi_picture`
-- -----------------------------
INSERT INTO `lovevi_picture` VALUES ('1', '/Uploads/Picture/2017-08-06/5986790e572ec.jpg', '', '3c1af29a693131a0e149c1519404dd3e', '7a4805a995d548099bd7908a44424fe6b0136d43', '1', '1501985036');
INSERT INTO `lovevi_picture` VALUES ('2', '/Uploads/Picture/2017-08-06/5986791e31092.jpg', '', '90d0f3e8f6304a0bd4779458c3a6b571', '56d9d9190d11edb174d53b2ffed3b3f70c697327', '1', '1501985053');
INSERT INTO `lovevi_picture` VALUES ('3', '/Uploads/Picture/2017-08-06/59867eed0712f.png', '', '92856f0bad0d6fe315084e2a54961f2c', 'f06edb7b8a63769b560b91a1c83a345dbf5f2dd0', '1', '1501986540');
INSERT INTO `lovevi_picture` VALUES ('4', '/Uploads/Picture/2017-08-06/59867f5e88c61.jpg', '', 'd9f652a52519eb91c1f63730ae5f2238', '5a974d037c7cdc2e9f4851c59cb62af09dbc13b3', '1', '1501986653');
INSERT INTO `lovevi_picture` VALUES ('5', '/Uploads/Picture/2017-08-06/59867fed6e122.jpg', '', '0bf2fbbd2fbfd9319ea000beba6888b9', '24eadf07e2a4ba00c24baf45ca222f8f9c321104', '1', '1501986796');
INSERT INTO `lovevi_picture` VALUES ('6', '/Uploads/Picture/2017-08-06/5986bc5fcd703.jpg', '', 'a042d2c2fbf8a55a1474bd008b6e62b8', '4a2d4aa2e565a0f9f9037c236f02120c82837d39', '1', '1502002271');
INSERT INTO `lovevi_picture` VALUES ('7', '/Uploads/Picture/2017-08-06/5986bceaba5d6.jpg', '', 'fae8d35a04ac7aab2e9e1c79edf3c564', '090a7aaf8e65798daa1e9d3a8ba455e009cef125', '1', '1502002410');
INSERT INTO `lovevi_picture` VALUES ('8', '/Uploads/Picture/2017-08-06/5986bd0788c61.jpg', '', 'fab46b4287591a2a2158ca8914b3e226', '7f447029da1d72e2094e6a49eebcf43765aa5592', '1', '1502002439');
INSERT INTO `lovevi_picture` VALUES ('9', '/Uploads/Picture/2017-08-06/5986bd295ecfe.jpg', '', 'd7917bce23dd31836a24ff34bf1dd5ee', '6e0d96a4005ca10aaba9478f8220136005e55077', '1', '1502002473');
INSERT INTO `lovevi_picture` VALUES ('10', '/Uploads/Picture/2017-08-06/5986beca66710.png', '', 'e272fe4515d4aeecfe035ae92bba9be7', '10bf4d5ac7da3a5a2e1011c28124218bbe59fbff', '1', '1502002890');
INSERT INTO `lovevi_picture` VALUES ('11', '/Uploads/Picture/2017-08-06/5986bed3d5115.png', '', '7e87f6ec4196ce6a55e3a9814f35af63', 'ff4ef782bd382db100802a3fdb5f6a320fdcfc4c', '1', '1502002899');
INSERT INTO `lovevi_picture` VALUES ('12', '/Uploads/Picture/2017-08-10/598bd81434d9b.png', '', 'a0d9baa7085d13961a9b635c579f0a98', 'afef7ab66b12cbe8858fe1de3502ac55b416e93b', '1', '1502337044');
INSERT INTO `lovevi_picture` VALUES ('13', '/Uploads/Picture/2017-12-17/5a35f983832a2.jpg', '', 'd7ce7227a1362318d3aaa6af7773066f', '9aa05d5675c10200b11bf5b452138b9435d3f83e', '1', '1513486723');
INSERT INTO `lovevi_picture` VALUES ('14', '/Uploads/Picture/2017-12-17/5a35f992b1031.jpg', '', 'ce43f927545f4d5b0111eb7f059af2b6', '008549028d5b5b33d071ec14f0076d58ce676997', '1', '1513486738');
INSERT INTO `lovevi_picture` VALUES ('15', '/Uploads/Picture/2017-12-17/5a35f99d18791.jpg', '', '24101901b8e28ee958a406b728a72ea3', '435246652033bc0e8b154e4350bc13a0626bb455', '1', '1513486749');
INSERT INTO `lovevi_picture` VALUES ('16', '/Uploads/Picture/2017-12-17/5a35f9a79a38d.jpg', '', 'f42a5087bef92e423523612b114ec727', '9037e25c31c2d786242a1606a159a6d8ece70865', '1', '1513486759');
INSERT INTO `lovevi_picture` VALUES ('17', '/Uploads/Picture/2017-12-17/5a35f9b13ae64.jpg', '', '4c719b16fc4d793de31723d452b980b5', '97a04e9652978425add327c476d2ac614b7c70ae', '1', '1513486769');
INSERT INTO `lovevi_picture` VALUES ('18', '/Uploads/Picture/2017-12-28/5a44ed0fa77c5.jpg', '', '8307c2d876c85a2af4f7d47efa506ff6', '1977ae451e0c93c9b3b913b34ac4e746d21d533b', '1', '1514466575');
INSERT INTO `lovevi_picture` VALUES ('19', '/Uploads/Picture/2017-12-28/5a44ed175f0df.jpg', '', '2a4c43f19ffd1e82d6cb1f68c103670a', '06994e1d28cd67fedb086a69aca676f4ce552629', '1', '1514466583');
INSERT INTO `lovevi_picture` VALUES ('20', '/Uploads/Picture/2017-12-28/5a44ed25948c9.jpg', '', 'f97932bcfed99523d9bc9bb7ed9d4e5a', '54c2c059de1854b054331a14d1dc1ba8e65027ae', '1', '1514466597');
INSERT INTO `lovevi_picture` VALUES ('21', '/Uploads/Picture/2017-12-28/5a44ed31d94a5.jpg', '', 'ee7ed1e8a5c663ce7c4d584de2af13a2', '5ec2c613348bbfc97930a714f04bea52ed1da804', '1', '1514466609');
INSERT INTO `lovevi_picture` VALUES ('22', '/Uploads/Picture/2017-12-28/5a44f5ba9fab7.jpg', '', '73b3f657a6f1f490163d35bd27731c4e', 'caef4459b4ba720c5910e1a84c7dc04e69e607e8', '1', '1514468794');
INSERT INTO `lovevi_picture` VALUES ('23', '/Uploads/Picture/2018-01-01/5a4a09fd04d9c.jpg', '', '5eeb31b311f4c0c98cef5c617ebece96', '8a699e29f2b31e120c511fe9c75b0af6e68de75a', '1', '1514801660');
INSERT INTO `lovevi_picture` VALUES ('24', '/Uploads/Picture/2018-01-01/5a4a197628085.jpg', '', 'e438af3e056cff0180f27679c7c11d3a', '0bb9ccf71e0f3e5c4c8e2c0e62550c59c706a868', '1', '1514805621');
INSERT INTO `lovevi_picture` VALUES ('25', '/Uploads/Picture/2018-01-04/5a4dd18c03feb.jpg', '', '5e1eb6d0942c15abb4e2e098ca8bf178', '146edaf683cf6f0c39696e19b857340e85be87a2', '1', '1515049355');
INSERT INTO `lovevi_picture` VALUES ('26', '/Uploads/Picture/2018-01-11/5a575bcc0c042.jpg', '', '7498b9f418d1c0d4a799e02beec3199b', 'f58ad900fb3aa4317d78a48eaa477990bf79f58c', '1', '1515674571');
INSERT INTO `lovevi_picture` VALUES ('27', '/Uploads/Picture/2018-01-11/5a575ce095586.jpg', '', '550a5c85ccf48e986452f035d17cbb70', '3734ddc3bc5aec753286339623add09b515a576d', '1', '1515674848');
INSERT INTO `lovevi_picture` VALUES ('28', '/Uploads/Picture/2018-01-11/5a575f32c6efb.jpg', '', '1fef52a187f29a9e2811a48f25f44731', '24ecb8ee9a6c935461747efb1bdf73b04df632a6', '1', '1515675442');
INSERT INTO `lovevi_picture` VALUES ('29', '/Uploads/Picture/2018-01-11/5a5761573d9b7.jpg', '', '9d98a6deab29c6c409791e793873083c', 'f7e6daae0ab7288a1116b097a8a2e97d33dae7b0', '1', '1515675990');
INSERT INTO `lovevi_picture` VALUES ('30', '/Uploads/Picture/2018-01-11/5a5761dac31f2.jpg', '', 'fcc4dc9c16e5a1415dbe0387ebaa1070', '432c9a9fd5d8fc01275fc4114c3d6213cfd24b8a', '1', '1515676122');
INSERT INTO `lovevi_picture` VALUES ('31', '/Uploads/Picture/2018-01-11/5a5763266f32c.jpg', '', 'c4d57f906e7eeada03c00577ab4074dd', 'df882cf3e78e1038411107bb297682b336a0ea32', '1', '1515676454');
INSERT INTO `lovevi_picture` VALUES ('32', '/Uploads/Picture/2018-01-11/5a57662e6f32c.jpg', '', '2901c6ec1738c1996824595084f5d386', '7fadeb2959c041813f15962f8867239785ac22c3', '1', '1515677226');
INSERT INTO `lovevi_picture` VALUES ('33', '/Uploads/Picture/2018-01-11/5a576beb00b3b.jpg', '', 'f60345b466f2d455295ba0739edeb304', '00a98e8e16f2864f2ef02e91fa26cf022973c84b', '1', '1515678698');
INSERT INTO `lovevi_picture` VALUES ('34', '/Uploads/Picture/2018-01-11/5a576cbf8dd88.jpg', '', 'ff6e0e140d4a4e2260914830e0dda6f7', 'e1cfb37933583e741618d0f36b5e96ce6baa697c', '1', '1515678911');
INSERT INTO `lovevi_picture` VALUES ('35', '/Uploads/Picture/2018-01-11/5a57792bac5d0.jpg', '', 'a5080ea6eaf537a76db44022b6e170b1', '51040491e689cebb68bc2131766683a42ea3a7d8', '1', '1515682091');
INSERT INTO `lovevi_picture` VALUES ('36', '/Uploads/Picture/2018-01-11/5a57796fa88c7.jpg', '', '9c644c87b1d45935358ce767277bf1e3', '417a251437105613205dfaf125810e81058902e5', '1', '1515682159');
INSERT INTO `lovevi_picture` VALUES ('37', '/Uploads/Picture/2018-01-11/5a577ac14cfef.jpg', '', '447f4d0c50472f12d74e8572c94dd421', '1f256cf87bb364682ffa744886d9effc11fe9997', '1', '1515682497');
INSERT INTO `lovevi_picture` VALUES ('38', '/Uploads/Picture/2018-01-11/5a577b2c17971.jpg', '', '86a98d00dcdfd896ea0578d8cbbef0ce', '89cde194ba6072e0f82983f5c1424b15f7c7fba7', '1', '1515682603');
INSERT INTO `lovevi_picture` VALUES ('39', '/Uploads/Picture/2018-01-11/5a577b5a8266d.jpg', '', 'b0d4b968e0f2a60596ae60f4ef092caf', '4a7a47d52433968584cdc0c0537738a09eeebc2f', '1', '1515682650');
INSERT INTO `lovevi_picture` VALUES ('40', '/Uploads/Picture/2018-01-12/5a5797107ac5b.png', '', 'b75f1be41527aba0cb58b9dfa3b28c6f', 'c139fe54cd0cd2b16ad7c38c3ce6f47821cd2dcd', '1', '1515689743');
INSERT INTO `lovevi_picture` VALUES ('41', '/Uploads/Picture/2018-01-12/5a579754cae18.png', '', '7a52becb9957c9423ca8dfa95a97ca46', 'a50fc5e8ace5182bf988ae93403fb132b411aca1', '1', '1515689812');
INSERT INTO `lovevi_picture` VALUES ('42', '/Uploads/Picture/2018-01-12/5a579917c710f.jpg', '', '9404442ffc32613187725f406cd79b8c', '313f42de095d4952a3e7de482725be87c7b1769d', '1', '1515690263');
INSERT INTO `lovevi_picture` VALUES ('43', '/Uploads/Picture/2018-01-12/5a579ea77e964.jpg', '', '121c99008a43ec1c98ffe51b45e9cab4', '008b9d4b15a17b9d1209ec0fcc3f674c86cec80b', '1', '1515691687');
INSERT INTO `lovevi_picture` VALUES ('44', '/Uploads/Picture/2018-01-12/5a579f80994a3.jpg', '', '377629d660f49bb7358219f80afddb52', 'e528cd872167cd116b307130d2ce890e735870c2', '1', '1515691904');
INSERT INTO `lovevi_picture` VALUES ('45', '/Uploads/Picture/2018-01-12/5a57a10b1f383.jpg', '', 'b504da9e12c6da844f218314574b2931', '2260bdbf3a5005e2a79c8a8d177d426173a1dd29', '1', '1515692299');
INSERT INTO `lovevi_picture` VALUES ('46', '/Uploads/Picture/2018-01-12/5a57a215ac5d0.jpg', '', 'faaeb5ef3a58f225d4edf0938550f388', 'f3af8237861458b244cd95d1ee3473c6d119cdc8', '1', '1515692565');
INSERT INTO `lovevi_picture` VALUES ('47', '/Uploads/Picture/2018-01-12/5a57a2a7ac5d0.jpg', '', 'ca37be98eddf100165fec2cb1841afa2', '6a57d8dafb9be810592c75e1d59110e62e467bda', '1', '1515692711');
INSERT INTO `lovevi_picture` VALUES ('48', '/Uploads/Picture/2018-01-12/5a57a49713c68.jpg', '', '1e0e78a9b851d1e6a5883ded1e85f0b2', 'ed57b81511a2b9456b4d66df7d021230fd3cd33a', '1', '1515693206');
INSERT INTO `lovevi_picture` VALUES ('49', '/Uploads/Picture/2018-01-12/5a57aa5373249.jpg', '', '906d0231e6694897cfafd0ad835ed470', 'ed0f3056161516c22ba7ed8c35b9d179ef7fb566', '1', '1515694675');
INSERT INTO `lovevi_picture` VALUES ('50', '/Uploads/Picture/2018-01-12/5a57ac2f7e964.jpg', '', 'abb757df3c307645fe15946436e5f3c0', '2ead70816346e4ba9644d87d0dcbb7b082c6436a', '1', '1515695151');
INSERT INTO `lovevi_picture` VALUES ('51', '/Uploads/Picture/2018-01-12/5a57bf882e7a7.jpg', '', '67a9e6d602a449297f9c3c1ec6d667ea', '4f0c4cb60e98bbb1c800c919e7fe12df8fe102ba', '1', '1515700104');
INSERT INTO `lovevi_picture` VALUES ('52', '/Uploads/Picture/2018-01-12/5a57bfb426d95.jpg', '', '784cfdab88f0d516c5a75bc06cf96012', 'dd5f21c75b595599fa97cefe14c86aab25ba877f', '1', '1515700148');
INSERT INTO `lovevi_picture` VALUES ('53', '/Uploads/Picture/2018-01-12/5a57c014bf6fd.jpg', '', '5a610e87e1e76e6838e18b0e6c0d26a1', 'a9d94146362c8d4db232d4565e829ffecf0acff0', '1', '1515700244');
INSERT INTO `lovevi_picture` VALUES ('54', '/Uploads/Picture/2018-01-12/5a57c0509579a.jpg', '', '8fc182ba81ddb849f48347bf6df59bf6', '753f476205c73252878d263c88e48b75e00b7b8f', '1', '1515700304');
INSERT INTO `lovevi_picture` VALUES ('55', '/Uploads/Picture/2018-01-12/5a57c07700b3b.jpg', '', '1772e29bf15936175f6d9bdef0192aca', '4484a9e35b8015bb9dd7e8b32e252128a96a1e77', '1', '1515700342');
INSERT INTO `lovevi_picture` VALUES ('56', '/Uploads/Picture/2018-01-12/5a57c092cae18.jpg', '', 'b5e83b927da8242e45daa6a742c61414', '44876228f08f67a462bc72e9379d51b6f9827c41', '1', '1515700370');
INSERT INTO `lovevi_picture` VALUES ('57', '/Uploads/Picture/2018-01-12/5a57c0d90854d.jpg', '', '9c39c409e9334523546a2d5e45ac52ee', '3eee5379baa93f0e8ef233771d8b1970e2d8918c', '1', '1515700440');
INSERT INTO `lovevi_picture` VALUES ('58', '/Uploads/Picture/2018-01-12/5a57c0fb0854d.jpg', '', 'd0310d39bd811bedaf6bfe866b7f251e', '5aa6e920de30cb3678ad197b677c1cbc98671a26', '1', '1515700474');
INSERT INTO `lovevi_picture` VALUES ('59', '/Uploads/Picture/2018-01-12/5a57c15b54a01.jpg', '', '9e784a2fbe9f60c6df2b746cf5301e0e', 'f3bc1fa6a98bebb856f833042e8383d8d826c9e9', '1', '1515700571');
INSERT INTO `lovevi_picture` VALUES ('60', '/Uploads/Picture/2018-01-12/5a57c1792e7a7.jpg', '', 'e713961deb30e6c017e8600331fddcb8', '6c8e2d7594653ae2855d279a4695579266a8d263', '1', '1515700600');
INSERT INTO `lovevi_picture` VALUES ('61', '/Uploads/Picture/2018-01-12/5a57c1b5cae18.jpg', '', '4bc60d0f1cafcb96b8669ca7023ef33d', 'a91ba6cdc381780f4d47d29dc15165a019d64c0d', '1', '1515700661');
INSERT INTO `lovevi_picture` VALUES ('62', '/Uploads/Picture/2018-01-12/5a57c240994a3.jpg', '', '9d9fed44106624b4bd9087e6b912585b', '78f61b64b782b0e7799a9440b10f5233d2b7afdb', '1', '1515700800');
INSERT INTO `lovevi_picture` VALUES ('63', '/Uploads/Picture/2018-01-12/5a57c29639ec2.jpg', '', '929fa15f1d4cd1f243291c7b755455a0', '2ce66c1e0fd112cf8e9fc6606df76cba1cb7cdab', '1', '1515700886');
INSERT INTO `lovevi_picture` VALUES ('64', '/Uploads/Picture/2018-01-12/5a57c2c90854d.jpg', '', 'f1c06f9aa16caffa99ba42264c96985b', '086cd41bede1d11fb32bbcfb974757da45bf5163', '1', '1515700936');
INSERT INTO `lovevi_picture` VALUES ('65', '/Uploads/Picture/2018-01-12/5a57c2ebac5d0.jpg', '', 'a0510dec7d9795d1eff33086c38bfeef', '729a352fc8967e2f3b554ed9eef95930329bc107', '1', '1515700971');
INSERT INTO `lovevi_picture` VALUES ('66', '/Uploads/Picture/2018-01-12/5a57c305cae18.jpg', '', '542e753aa56bca5e965c14814b5b884a', '46548a50d199f62bd7bb479f17ede12d45744f26', '1', '1515700997');
INSERT INTO `lovevi_picture` VALUES ('67', '/Uploads/Picture/2018-01-12/5a57c3540ff5f.jpg', '', '36c98b5a8118a99a32efc0bef52295a8', '5c03cb9157896791382cb78f800f12853ddc7691', '1', '1515701075');
INSERT INTO `lovevi_picture` VALUES ('68', '/Uploads/Picture/2018-01-12/5a57c3927e964.jpg', '', 'bb13b013fc11ed5e5fe7e6e66c0311e0', '15703ebe158d6afc37f95ed0eea5f14a29bc13d1', '1', '1515701138');
INSERT INTO `lovevi_picture` VALUES ('69', '/Uploads/Picture/2018-01-12/5a57c3bb00b3b.jpg', '', '39dfa8796daf012d2b6fbb930e9b23e5', '0cedc6e382b934f97d47818c39c5c881712f856a', '1', '1515701178');
INSERT INTO `lovevi_picture` VALUES ('70', '/Uploads/Picture/2018-01-12/5a57c3db2aa9e.jpg', '', '96137baa994c975344f34fc5a584db33', 'c607eb79234b4913a97a265356864bf5b3a3c498', '1', '1515701211');
INSERT INTO `lovevi_picture` VALUES ('71', '/Uploads/Picture/2018-01-12/5a57c42276f52.jpg', '', '3e67733c1d419f0f5103486915954c13', '3f4d788d61d1df38bafff47cc72dfe258ab0a25a', '1', '1515701282');
INSERT INTO `lovevi_picture` VALUES ('72', '/Uploads/Picture/2018-01-12/5a57c45ec710f.jpg', '', '4a0b153e70b4c1734677a1cfd1816618', '931c1f9c3ac9355a8f2b95bd5210d6e4ba857a73', '1', '1515701342');
INSERT INTO `lovevi_picture` VALUES ('73', '/Uploads/Picture/2018-01-12/5a57c4c5e9660.jpg', '', 'a5664610a71d2937592c07acd997f13a', 'bb28f4cc0175fb2fbd069c86a6cb37ba31c84788', '1', '1515701445');
INSERT INTO `lovevi_picture` VALUES ('74', '/Uploads/Picture/2018-01-12/5a57c4feda23c.jpg', '', 'a2885b236686824b8c9e90f5b2cb0915', '1ff09c04e60df885355c04b1b8a2e72e42e85f9e', '1', '1515701502');
INSERT INTO `lovevi_picture` VALUES ('75', '/Uploads/Picture/2018-01-12/5a57c535c710f.jpg', '', 'f1800b105288421ca5a3b651dafaa24b', '9192dcbdba49c6396076c9a7a6f4e99fd50e345e', '1', '1515701557');
INSERT INTO `lovevi_picture` VALUES ('76', '/Uploads/Picture/2018-01-12/5a57c55de9660.jpg', '', '331b15774a407044a0b1dbb1b6372aba', 'dc9a913d269b58a19c4c437e32bf83667b818927', '1', '1515701597');
INSERT INTO `lovevi_picture` VALUES ('77', '/Uploads/Picture/2018-01-12/5a57c5b354a01.jpg', '', 'b6916a1a48c489b7b9a152de4165dff7', 'eae0534a5b3b900ecba7ce95fba1e259f05959f9', '1', '1515701683');
INSERT INTO `lovevi_picture` VALUES ('78', '/Uploads/Picture/2018-01-12/5a57c5e913c68.jpg', '', 'da9e2809019f9d8793a58d7394c05bf8', '83b1fea954de43ac2fa1ba50efd03861791c097f', '1', '1515701736');
INSERT INTO `lovevi_picture` VALUES ('79', '/Uploads/Picture/2018-01-12/5a57c60eb02d9.jpg', '', '38485f05f4de3b355c3177cc17eefcf1', 'ddef3f77763906a3ca720aa79ca81fd26524c736', '1', '1515701774');
INSERT INTO `lovevi_picture` VALUES ('80', '/Uploads/Picture/2018-01-12/5a57c63ce1c4e.jpg', '', '7cf5bc188eeef62418633d4af51e6d06', '5b41f724169484ac9c70263d34d6d3abb201ac3f', '1', '1515701820');
INSERT INTO `lovevi_picture` VALUES ('81', '/Uploads/Picture/2018-01-12/5a57c66417971.jpg', '', '07543d7e8cd24e37cd6725cff41ed17f', '2ef8e0250a9c7e79112b08053f0b6258ee199c82', '1', '1515701859');
INSERT INTO `lovevi_picture` VALUES ('82', '/Uploads/Picture/2018-01-12/5a57c6908a07f.jpg', '', 'c04863f875bea8993286e1a1ac4bfcf5', '5cd5b7d9aa9968be66ddaf10b57e32a11ee7578f', '1', '1515701904');
INSERT INTO `lovevi_picture` VALUES ('83', '/Uploads/Picture/2018-01-12/5a57c6b3ac5d0.jpg', '', 'e30765df2d14d251c72d39311c160519', 'a3b8005f810814424ca5999bd1c8500408713d86', '1', '1515701939');
INSERT INTO `lovevi_picture` VALUES ('84', '/Uploads/Picture/2018-01-12/5a57c6e454a01.jpg', '', '3c9586e4a64d4a88949fbcbf2bd80f82', '022f5d5093505a65fcd2af8326a05447ecdd4b01', '1', '1515701987');
INSERT INTO `lovevi_picture` VALUES ('85', '/Uploads/Picture/2018-01-12/5a57c71e8a07f.jpg', '', '718c93b3307feb831ede0d1d4459d01f', '7db8bd358001365abb3f31d5f749efacccfebd2a', '1', '1515702046');
INSERT INTO `lovevi_picture` VALUES ('86', '/Uploads/Picture/2018-01-12/5a57c74a0c256.jpg', '', '2c8b5d077de65df5ab5202b61d961fff', '723ac3292a66458142421d8bd99b403c673e89e3', '1', '1515702089');
INSERT INTO `lovevi_picture` VALUES ('87', '/Uploads/Picture/2018-01-12/5a57c7cae9660.jpg', '', 'c88cde93eba113057e415e8e7ab9c455', '9f33b2dbdc706df699cc8ac2afbc7f1e65887fd8', '1', '1515702218');
INSERT INTO `lovevi_picture` VALUES ('88', '/Uploads/Picture/2018-01-12/5a57c7f1bb9f4.jpg', '', '85b0c177de6865ab2f4bd7f2c2c16711', 'c48c4400ab617f706c95930a122363301dc1bdd3', '1', '1515702257');
INSERT INTO `lovevi_picture` VALUES ('89', '/Uploads/Picture/2018-01-12/5a57c832492e6.jpg', '', 'ff0d7015f3ec1f8676c8d31da00da6d6', 'a64c0e84e73c70159f65b7c5efc86e4222395531', '1', '1515702322');
INSERT INTO `lovevi_picture` VALUES ('90', '/Uploads/Picture/2018-01-12/5a57c84eb02d9.jpg', '', 'e9e68da2fe11c2e66c511274792a444d', 'f342bd9c39fd9f75f44e7852127cd190a3f971de', '1', '1515702350');
INSERT INTO `lovevi_picture` VALUES ('91', '/Uploads/Picture/2018-01-12/5a57c8b38266d.jpg', '', '1a2f008a80e7b423cb27231e59fcf1ed', '6f11c4c334baf96f5eeb5b22bdc73215b350244c', '1', '1515702451');
INSERT INTO `lovevi_picture` VALUES ('92', '/Uploads/Picture/2018-01-12/5a57c90bb3fe2.jpg', '', 'd65a742310379842bfa063a93d1eb2f1', 'b9163299ce1a00b91ed5a756282d6ed94dc732d0', '1', '1515702539');
INSERT INTO `lovevi_picture` VALUES ('93', '/Uploads/Picture/2018-01-12/5a57c93663e25.jpg', '', '163728d8fa4bfc4b1a27693efae0d547', '8683a3335b49282c11c224ff39212705c1501ff2', '1', '1515702582');
INSERT INTO `lovevi_picture` VALUES ('94', '/Uploads/Picture/2018-01-12/5a57cbd9cae18.jpg', '', '8df48077f44b9484ba992a0246f23e60', '30b2587e695434f4a20ff3d47d9272698c0892d6', '1', '1515703257');
INSERT INTO `lovevi_picture` VALUES ('95', '/Uploads/Picture/2018-01-12/5a57cc00c3406.jpg', '', 'e4561ef74c96a1eb983c2b3a44f6ae5b', '47c523ad29ff8ac50da6f0f3ecd8af05ba8f9328', '1', '1515703296');
INSERT INTO `lovevi_picture` VALUES ('96', '/Uploads/Picture/2018-01-12/5a57cc4317971.jpg', '', '2a0180839261d6afdf2c941034be5b40', '56d4e5080ab949166155fb30ba6c06bcd59c44a0', '1', '1515703362');
INSERT INTO `lovevi_picture` VALUES ('97', '/Uploads/Picture/2018-01-12/5a57cc601f383.jpg', '', 'c8f98d1bd1dd1a724dd7d66daca7fa35', '32366947420cb226197fb0c405485157658cb529', '1', '1515703391');
INSERT INTO `lovevi_picture` VALUES ('98', '/Uploads/Picture/2018-01-12/5a57cc9b8266d.jpg', '', 'f9b93b3b869b65e21cbc8fe52b0d167e', '050907dd376df045b81abe549b80cf0fe94241e9', '1', '1515703451');
INSERT INTO `lovevi_picture` VALUES ('99', '/Uploads/Picture/2018-01-12/5a57cce40854d.jpg', '', 'a5adec9edf94a5588060c5b23dad0c2f', '06a7cf81f00956998d058a2ee113654046eb66c8', '1', '1515703523');
INSERT INTO `lovevi_picture` VALUES ('100', '/Uploads/Picture/2018-01-12/5a57ccfe0ff5f.jpg', '', '66249d144c423c69651accc0897f0e07', 'f933a3aed1c05cb4a2fbfde3fee56fad078bbf75', '1', '1515703549');
INSERT INTO `lovevi_picture` VALUES ('101', '/Uploads/Picture/2018-01-12/5a57cd0f3dbcb.jpg', '', '1559f3424e904a2dbbf48390e31aa406', 'd9faa51f7d76f5cf0498b71da9ced444596e031e', '1', '1515703567');
INSERT INTO `lovevi_picture` VALUES ('102', '/Uploads/Picture/2018-01-12/5a57cd3d13c68.jpg', '', '2bb6850292703f9914381c061383f3af', '8662d1964a470f69f962c9716b52c5ed1f0671d9', '1', '1515703612');
INSERT INTO `lovevi_picture` VALUES ('103', '/Uploads/Picture/2018-01-12/5a57cd5dc3406.jpg', '', '6d0177d854e76c630d9e38d8bf55c972', '7048dfb3bf80b8adf7e7f346b5b1bebf4326d697', '1', '1515703645');
INSERT INTO `lovevi_picture` VALUES ('104', '/Uploads/Picture/2018-01-12/5a57cd92ed369.jpg', '', '7b3eba660c2c88c3cf188a6750aa7c85', '8e1e828cdb317dbcbd7ce91e9641f8cc5ae0192d', '1', '1515703698');
INSERT INTO `lovevi_picture` VALUES ('105', '/Uploads/Picture/2018-01-12/5a57cdb1f1072.jpg', '', 'ddf97217003fabdb04abceea812dfd7d', 'a960154480666f138ca5e2683b25890371fc128a', '1', '1515703729');
INSERT INTO `lovevi_picture` VALUES ('106', '/Uploads/Picture/2018-01-12/5a57cdd0b7ceb.jpg', '', 'f37a220387380d3dc0fe6c35687de8d9', '6fa6aef0645090dad5c8d0760488b8c5ace7940d', '1', '1515703760');
INSERT INTO `lovevi_picture` VALUES ('107', '/Uploads/Picture/2018-01-12/5a57cdf56f540.jpg', '', 'fa2a4a6f9fde7d33bf07b7008f1103de', '6cb31ad3e0e9fa36371c064bed6a8a692974c5ed', '1', '1515703797');
INSERT INTO `lovevi_picture` VALUES ('108', '/Uploads/Picture/2018-01-12/5a57ce1f6b837.jpg', '', '55b9bd1a90dba52ef18a3391179656c1', 'c24b43207bace083a8155024f00f93cd5b47e3af', '1', '1515703839');
INSERT INTO `lovevi_picture` VALUES ('109', '/Uploads/Picture/2018-01-12/5a57ce4b50cf8.jpg', '', '24b2c0c648e9e05fee4639cfae8e1da0', 'ffb13f4588e1fa68fe0d1ae93f44cb2e5257a3f1', '1', '1515703883');
INSERT INTO `lovevi_picture` VALUES ('110', '/Uploads/Picture/2018-01-12/5a57ce7cda23c.jpg', '', 'b8d4b521ad3d576df476b2fb141f16b7', 'b24baa1b9b4e54be832626933b85d9711ad10218', '1', '1515703932');
INSERT INTO `lovevi_picture` VALUES ('111', '/Uploads/Picture/2018-01-12/5a57ce98ac5d0.jpg', '', 'c0b543e3dcf1c18e626eb96c15ac1ba6', 'ac00f8d87a4cbfc8eadd02fc235225ff2b6137a8', '1', '1515703960');
INSERT INTO `lovevi_picture` VALUES ('112', '/Uploads/Picture/2018-01-12/5a57ceac91a91.jpg', '', 'ae368c9c667c820d9e69df75fc0e287b', 'dcc576e4259ede4c199482af0b1866f4827d9744', '1', '1515703980');
INSERT INTO `lovevi_picture` VALUES ('113', '/Uploads/Picture/2018-01-12/5a57ced6a4bbe.jpg', '', '5d13c008467e056f276cd2c4701a205c', 'e3d83c4c4811f9ae9c51e53df64b0363f5689a15', '1', '1515704022');
INSERT INTO `lovevi_picture` VALUES ('114', '/Uploads/Picture/2018-01-12/5a57ceff86376.jpg', '', '1b36853e5ef86af2847d3423497dc9b8', '13f42433657926ec2b6056c82f431882ad750b89', '1', '1515704063');
INSERT INTO `lovevi_picture` VALUES ('115', '/Uploads/Picture/2018-01-12/5a57cf1bc710f.jpg', '', 'e2cca6c914e252bd21dc62e563fd13c2', '41474e58a35ef9df99493b31a8c6114e0c420b36', '1', '1515704091');
INSERT INTO `lovevi_picture` VALUES ('116', '/Uploads/Picture/2018-01-12/5a57cf3a2308c.jpg', '', '9324bc12c1b45ce33a30f4d568ba0b89', 'fffd6942555ffacaed7981c337be26ef630edc44', '1', '1515704122');
INSERT INTO `lovevi_picture` VALUES ('117', '/Uploads/Picture/2018-01-12/5a57d7eb1b67a.jpg', '', '6af5a4e88a5099fed13e5f5af279b81a', 'a6d94f72da2581320b17098df00da25ab7fc4446', '1', '1515706346');
INSERT INTO `lovevi_picture` VALUES ('118', '/Uploads/Picture/2018-01-12/5a57d9370ff5f.png', '', '867c490948e2b01c3ef9e7f701ac0ed6', 'd9f6c2958ece813eb97b3f3b003d92a07dee0826', '1', '1515706678');
INSERT INTO `lovevi_picture` VALUES ('119', '/Uploads/Picture/2018-01-12/5a57dd553dbcb.jpg', '', 'e8eb3b19fe8a098a702cdab2ae366a38', '500b25b37cde3c80186f53cc2097082a7d3c58d5', '1', '1515707733');
INSERT INTO `lovevi_picture` VALUES ('120', '/Uploads/Picture/2018-01-12/5a57dd780ff5f.jpg', '', '4cd14ffb97415d35145bd2ff5ccdf7d8', '6d6434210d3d01be9ccde763cc91ade19f9c1710', '1', '1515707767');
INSERT INTO `lovevi_picture` VALUES ('121', '/Uploads/Picture/2018-01-12/5a57ddbef1072.jpg', '', '47e8a9f2580fd57307e17f6337e0d089', '45c249345a963cef7f50a808fe4fce2025fe44a2', '1', '1515707838');
INSERT INTO `lovevi_picture` VALUES ('122', '/Uploads/Picture/2018-01-12/5a57ddd9d6533.jpg', '', '742e0ce98d80f71aa9717198a6d60625', '24a1080168cf6ceea1f35927d119d92d094d8eb2', '1', '1515707865');
INSERT INTO `lovevi_picture` VALUES ('123', '/Uploads/Picture/2018-01-12/5a57de7bb3fe2.jpg', '', '765b3674252dc27ce31a86ad0b6abf09', 'f65526503767e5208104c05774f75d51b224f395', '1', '1515708027');
INSERT INTO `lovevi_picture` VALUES ('124', '/Uploads/Picture/2018-01-12/5a57dec573249.jpg', '', 'b2f159368d3182b01e34541db8ddc24c', 'b79c3ee75356334213d8f422d2d34787b3969446', '1', '1515708101');
INSERT INTO `lovevi_picture` VALUES ('125', '/Uploads/Picture/2018-01-12/5a57df0e3dbcb.jpg', '', '4b707513c411d47f17e3ca248f5a1e05', '2e48aacabc60aa82167f784c18b6ce3a19c3278e', '1', '1515708174');
INSERT INTO `lovevi_picture` VALUES ('126', '/Uploads/Picture/2018-01-12/5a57df23d6533.jpg', '', '16028ba0750f0cf3d83180e84390bd5f', '36a53f3855276d4db3cc667f70f15ab49a84255b', '1', '1515708195');
INSERT INTO `lovevi_picture` VALUES ('127', '/Uploads/Picture/2018-01-12/5a57dfb80ff5f.jpg', '', 'e0e6ebb15b5dce5d1cc9555945886402', '3b579c64a667d2189a39b198d8c407a0b30755c6', '1', '1515708343');
INSERT INTO `lovevi_picture` VALUES ('128', '/Uploads/Picture/2018-01-12/5a57dfe0d282a.jpg', '', 'b1c5c5d1e0b6f955b107d483ff58e02a', '01856fc4d65a7a77368db94c2e31e1610fda2b7d', '1', '1515708384');
INSERT INTO `lovevi_picture` VALUES ('129', '/Uploads/Picture/2018-01-12/5a57e006c710f.jpg', '', 'b79104e4149d607f503acbb11b3739bf', '7aa9659ee246a6374883df529a01b81b0dd30d89', '1', '1515708422');
INSERT INTO `lovevi_picture` VALUES ('130', '/Uploads/Picture/2018-01-12/5a57e02154a01.jpg', '', 'b433aa3d72a2601bf206c38abac5c223', '939baa603be622ca94b7c5c6bd5382f8d269d5ee', '1', '1515708449');
INSERT INTO `lovevi_picture` VALUES ('131', '/Uploads/Picture/2018-01-12/5a57e03a91a91.jpg', '', '3316e0ebbec1981b1c8377c7f34c7982', '14b22654c9508053bf4058521ad428567b7e31df', '1', '1515708474');
INSERT INTO `lovevi_picture` VALUES ('132', '/Uploads/Picture/2018-01-12/5a57e065bb9f4.jpg', '', 'fd20589623f6fa44700dc6ba0fc5e18c', '00c0d972134bd5b3d2b9a935ed727604a6ee2945', '1', '1515708517');
INSERT INTO `lovevi_picture` VALUES ('133', '/Uploads/Picture/2018-01-12/5a57e0976011c.jpg', '', 'e76c8e24366102fc90c2a318ad93c227', '2d2bd8b09a76cac49778eb326d20bb3a31dcff70', '1', '1515708567');
INSERT INTO `lovevi_picture` VALUES ('134', '/Uploads/Picture/2018-01-12/5a57e0bc9579a.jpg', '', 'd532cfd085e060b17e3bc8fb721b3beb', 'ed1d51a87061e5a0b31081b24ce89555ea1ad700', '1', '1515708604');
INSERT INTO `lovevi_picture` VALUES ('135', '/Uploads/Picture/2018-01-13/5a59cbe78ca33.jpg', '', '4945483dbd93b14f686bbcc0a762dbab', 'ae1ef6d07e3919f682f6e222c593a2522ad1c75b', '1', '1515834343');
INSERT INTO `lovevi_picture` VALUES ('136', '/Uploads/Picture/2018-01-13/5a59cc280ad64.jpg', '', '6bb1dc064a8a8395fcffcd578ae063bb', 'f88945d753bad77f4a3f171d0376f0fbb92be8bc', '1', '1515834407');
INSERT INTO `lovevi_picture` VALUES ('137', '/Uploads/Picture/2018-01-16/5a5cee35057d0.jpg', '', 'fd7fccdec390f6eba276db09ff38c725', '3aa4247dce395cfebfb1e59e3f540fac4b3c6bd4', '1', '1516039732');
INSERT INTO `lovevi_picture` VALUES ('138', '/Uploads/Picture/2018-01-16/5a5cee7e094d9.jpg', '', '1b14b924e73dd0065ef16f48e87fd444', '5a319a739b8939687b40d921b773959a60d8d3b7', '1', '1516039805');
INSERT INTO `lovevi_picture` VALUES ('139', '/Uploads/Picture/2018-01-16/5a5ceea496726.jpg', '', '7a4823a7c0cecef8e8f8e01faf644546', '7c48c705dffd21d1345e3ecc44d7f4fa34f0e1f3', '1', '1516039844');
INSERT INTO `lovevi_picture` VALUES ('140', '/Uploads/Picture/2018-01-16/5a5ceed2c809b.jpg', '', 'ca1745e770d27b0e526cb3a09e427aae', '05a5eca6b33f7a94492ce27adb2ba6c7d2b17292', '1', '1516039890');
INSERT INTO `lovevi_picture` VALUES ('141', '/Uploads/Picture/2018-01-16/5a5ceefec0689.jpg', '', 'ed558ba4796ac619fbb7dd81b546a954', '7ba6e085ae22160901f5513ecd5c92121fe73a40', '1', '1516039934');
INSERT INTO `lovevi_picture` VALUES ('142', '/Uploads/Picture/2018-01-16/5a5cef1a68aba.jpg', '', 'bbd105d469dee82afe92abad128bc2f1', '2fd24f312dea7dd7caa69ab547efab0dbe75fa9f', '1', '1516039962');
INSERT INTO `lovevi_picture` VALUES ('143', '/Uploads/Picture/2018-01-16/5a5cef3c14bf4.jpg', '', '3cc7d43aa5d61bbae1c0829ee1810308', '1c48996884e4b5e799f0c25f910be217369d48ad', '1', '1516039995');
INSERT INTO `lovevi_picture` VALUES ('144', '/Uploads/Picture/2018-01-16/5a5cef764a272.jpg', '', '0d976bbba7f26277bd575c8bb7bbbc1f', '1bd99b7c797ca082b761260ecdc6d28a57d59ae4', '1', '1516040054');
INSERT INTO `lovevi_picture` VALUES ('145', '/Uploads/Picture/2018-01-16/5a5cef9577ede.jpg', '', '70e024334d477cea3e28211139e2e355', 'f0ce0628aad87689fd2131a0e7b97397c28f338e', '1', '1516040085');
INSERT INTO `lovevi_picture` VALUES ('146', '/Uploads/Picture/2018-01-16/5a5cefb52ba2a.jpg', '', '485bb9b5ece127e748cabe79a09e1063', '516163a546621ad479a0e073728fe4764eb538df', '1', '1516040117');
INSERT INTO `lovevi_picture` VALUES ('147', '/Uploads/Picture/2018-01-16/5a5cefd2741d5.jpg', '', '93351898e75230a4837e57ace78e87e3', '3a7690764162d1817c2389bd5e4a6ed4f90b7e02', '1', '1516040146');
INSERT INTO `lovevi_picture` VALUES ('148', '/Uploads/Picture/2018-01-16/5a5ceff7a5b4a.jpg', '', '8cea543b19248c1b4043cbfbdeea105b', '0a6fecea650f3ce3e583e03e32b8a226fd198dda', '1', '1516040183');
INSERT INTO `lovevi_picture` VALUES ('149', '/Uploads/Picture/2018-01-16/5a5cf00a057d0.jpg', '', 'a9d4b33fe1d55b1bf0b0d3b4db801001', '79617ae26fb4d72b54e162fba2f3cfcf26a67636', '1', '1516040201');
INSERT INTO `lovevi_picture` VALUES ('150', '/Uploads/Picture/2018-01-16/5a5cf0358ed14.jpg', '', '0255b7f23a2e6ed24f13d75363c8224b', '4c80dc03b38f12f4db787324ae79bb9516f1f64a', '1', '1516040245');
INSERT INTO `lovevi_picture` VALUES ('151', '/Uploads/Picture/2018-01-16/5a5cf0979e138.jpg', '', 'fc39472c3fb707bf68f6ab1684e3da4c', '944d1ad184c9f2d135c4c204362d7cee6e1a0081', '1', '1516040343');
INSERT INTO `lovevi_picture` VALUES ('152', '/Uploads/Picture/2018-01-17/5a5e707f0ccc3.png', '', '7a05e63947a22a9cb5fcf7afad399b18', '8165bb0c71090fa3e31f0c8f8bdecadb921847a9', '1', '1516138622');
INSERT INTO `lovevi_picture` VALUES ('153', '/Uploads/Picture/2018-01-17/5a5e710bd2f11.png', '', 'bf1157d4e3a45672789447a910a41744', 'fa1f766aa396c026c7640b60ec74906ace4247c7', '1', '1516138763');
INSERT INTO `lovevi_picture` VALUES ('154', '/Uploads/Picture/2018-01-17/5a5e717be2068.png', '', '3d1a7f01c45c2f397cf365b424a1ebf5', 'fdba1f03007c50dc1a8f4fb75185b543f995963c', '1', '1516138875');
INSERT INTO `lovevi_picture` VALUES ('155', '/Uploads/Picture/2018-01-17/5a5e71b17350d.png', '', '64b8058804cf7a157991a709e60a54c1', 'a277c0eacf2daed3f607375e83ddef027475200b', '1', '1516138929');
INSERT INTO `lovevi_picture` VALUES ('156', '/Uploads/Picture/2018-01-17/5a5e71e71b7e6.png', '', '91616f0f06f67fee03876d4c280dc713', '62068eac2c822c1697280a30abf65c5150c962d6', '1', '1516138982');
INSERT INTO `lovevi_picture` VALUES ('157', '/Uploads/Picture/2018-01-17/5a5e71fd5c4f1.png', '', 'a327c851c2b9da1b0dafc632d62192c3', 'b2713ed9f4a700db40d30dc7ef2ac25d013f0097', '1', '1516139005');
INSERT INTO `lovevi_picture` VALUES ('158', '/Uploads/Picture/2018-01-17/5a5e7263824bd.png', '', 'd124ceeacfa36fb2ac3b9255c6e776c0', 'ccdcac9c8ca381cb3a99ce7348a13120adf80b0b', '1', '1516139107');
INSERT INTO `lovevi_picture` VALUES ('159', '/Uploads/Picture/2018-01-18/5a60befb9b194.jpg', '', '34445baad3568aa31e59ac4a305ef862', 'b6c874495d99cc23277e2f3114451c932725a440', '1', '1516289786');
INSERT INTO `lovevi_picture` VALUES ('160', '/Uploads/Picture/2018-01-18/5a60bf05750f3.png', '', 'c6db4019e46622f5a81cf0de10b5bfe2', 'f255863481dff517b64fd9773e28347bc6429d9d', '1', '1516289797');
INSERT INTO `lovevi_picture` VALUES ('161', '/Uploads/Picture/2018-01-18/5a60bf8a35a95.png', '', 'f0d8ac9a5571c67eaf7c3e6ded213e93', '5ffe6b229777b88187e06ede2827e44e8492e5c9', '1', '1516289929');
INSERT INTO `lovevi_picture` VALUES ('162', '/Uploads/Picture/2018-01-18/5a60bfb2e1c49.png', '', '667abac805821323af31631019de1317', 'a295b9b424a1ed101b3a5bbe6b54e7c2e20de946', '1', '1516289970');
INSERT INTO `lovevi_picture` VALUES ('163', '/Uploads/Picture/2018-01-19/5a618ed4804f9.jpg', '', '285f939364062270695ce3b46c29c937', 'b28d2321e01879e53e797e903b0576a6fb4fda65', '1', '1516342996');
INSERT INTO `lovevi_picture` VALUES ('164', '/Uploads/Picture/2018-01-19/5a620c0a39d60.jpg', '', '53bc80d47d2422c949756795e60124a5', 'fcf298f445df18c8088d9f51466dc10fe2d35278', '1', '1516375049');
INSERT INTO `lovevi_picture` VALUES ('165', '/Uploads/Picture/2018-01-19/5a620ca3b7b89.jpg', '', 'c6e478d4ca1fe34316645843a7cc8223', '525d06c563540ba77ce71c2b9b7c602dcccd6a93', '1', '1516375203');
INSERT INTO `lovevi_picture` VALUES ('166', '/Uploads/Picture/2018-01-19/5a620ccdd26c8.jpg', '', '23f40701163b129932cb81598f46b81c', '2f04ded32ef94f2155385ed2d5c61d05e6a7013e', '1', '1516375245');
INSERT INTO `lovevi_picture` VALUES ('167', '/Uploads/Picture/2018-01-19/5a620d462e645.jpg', '', '32e6131e778d91a6d07840812c151b2e', '77aab45db02363ec3c2f9e3b71e16f828c3ebb7a', '1', '1516375365');
INSERT INTO `lovevi_picture` VALUES ('168', '/Uploads/Picture/2018-01-19/5a620d6bb3e80.jpg', '', 'eff52804370a255af2ae00e8e76df4eb', '4cec2fccf896682191c1b33b9320dc1ea92a7b2e', '1', '1516375403');
INSERT INTO `lovevi_picture` VALUES ('169', '/Uploads/Picture/2018-01-19/5a620db5a0d53.jpg', '', '7984a97777179d9d8d99858d5b6e253a', '8e8babe7865728439011b0e328c7110443b6b69a', '1', '1516375477');
INSERT INTO `lovevi_picture` VALUES ('170', '/Uploads/Picture/2018-01-19/5a620dd676df0.jpg', '', 'd25ee910a6129f8fee4427b5ca41fde0', 'eb1cf0f6f5670c76fc5d9041144ec9287d26d24b', '1', '1516375510');
INSERT INTO `lovevi_picture` VALUES ('171', '/Uploads/Picture/2018-01-19/5a620dfd1f221.jpg', '', '124ca2f3ff6e5b4b9d3131fe23e240fa', '02d12fcf066c156a3e960a45531766211f6bf0bc', '1', '1516375548');
INSERT INTO `lovevi_picture` VALUES ('172', '/Uploads/Picture/2018-01-19/5a620e50679cc.jpg', '', '0ac5af67568823a867f2d1e696b0c691', 'eb0ace3331145d13a51d73531f7ad5a8883b30c1', '1', '1516375631');
INSERT INTO `lovevi_picture` VALUES ('173', '/Uploads/Picture/2018-01-19/5a620ea4da0da.jpg', '', 'd8a6c59fdb7fe1401b86147bedea2b40', '79d0c411d301cdf9e95b6ff306e6456b7fa57ad8', '1', '1516375716');
INSERT INTO `lovevi_picture` VALUES ('174', '/Uploads/Picture/2018-01-19/5a620eed26c33.jpg', '', '5301d852937d9489f3dd08912b203ce8', 'a7078da809b632a308bd502185ad8be6bd215908', '1', '1516375788');
INSERT INTO `lovevi_picture` VALUES ('175', '/Uploads/Picture/2018-01-19/5a620f302e645.jpg', '', 'a27da3a85c4a5d85ffd417df16d8d0c4', 'a472ada7c6818e0007d5d17208e4ae95d3d793d4', '1', '1516375855');
INSERT INTO `lovevi_picture` VALUES ('176', '/Uploads/Picture/2018-01-19/5a620f66e1aec.jpg', '', '50f5402750dbbb5201cc0e14bc4f3c1e', '21acee5685b51ee2354d4b603859582ccac305d0', '1', '1516375910');
INSERT INTO `lovevi_picture` VALUES ('177', '/Uploads/Picture/2018-01-19/5a620f925ffba.jpg', '', '06734af24226b9b4363ab571f4209dd0', '31e402be237a10c2f008c40d843cf34fac0ae562', '1', '1516375954');
INSERT INTO `lovevi_picture` VALUES ('178', '/Uploads/Picture/2018-01-19/5a620fc1e1aec.jpg', '', '239b1c38a2dca0f0750067e9c5ef28fa', '0000365f948a71304408e003486b39b48812a5a5', '1', '1516376001');
INSERT INTO `lovevi_picture` VALUES ('179', '/Uploads/Picture/2018-01-19/5a62105548c74.jpg', '', '0c442a4c08eb9086fefe3e826d7568ae', '434b8676ac596ea8f68bc681c9b473c816cfcf74', '1', '1516376149');
INSERT INTO `lovevi_picture` VALUES ('180', '/Uploads/Picture/2018-01-19/5a62107db7473.jpg', '', 'a6095ece3392df80c900c4c9d1a476d1', '21822b1c20eaad6ea376530ec3bb25e84bc477cc', '1', '1516376189');
INSERT INTO `lovevi_picture` VALUES ('181', '/Uploads/Picture/2018-01-19/5a6210e4724ae.jpg', '', '513eaac1f3f9ad4bf3af95929fd089ae', 'ef938c9ab8bf44920c5d3fa6d186f571b05e35d8', '1', '1516376292');
INSERT INTO `lovevi_picture` VALUES ('182', '/Uploads/Picture/2018-01-19/5a621153c5de3.jpg', '', 'c9c116f6a7f812b43d65c28f8c6fc726', 'b972717b96517cfeef35234bcd3465a38afc0c83', '1', '1516376403');
INSERT INTO `lovevi_picture` VALUES ('183', '/Uploads/Picture/2018-01-19/5a62119571bd5.jpg', '', '8f8359875fcdbe3e14bf74e993aa8902', '8a30068b5e22dedaa25adb0849b9c9a8f86b0235', '1', '1516376469');
INSERT INTO `lovevi_picture` VALUES ('184', '/Uploads/Picture/2018-01-19/5a6211dda31ad.jpg', '', '576dd7e94b85198b9c268ad80f04894e', '78e5d58cd2721579c96e603282face29596ae498', '1', '1516376541');
INSERT INTO `lovevi_picture` VALUES ('185', '/Uploads/Picture/2018-01-19/5a62121788389.jpg', '', '0c698ad821495a38f3e0f80ea87f9ab0', 'caa47b28e302ac2ee6adb0c01824856d837c0a34', '1', '1516376599');
INSERT INTO `lovevi_picture` VALUES ('186', '/Uploads/Picture/2018-01-19/5a6212408fb8e.jpg', '', 'd4b6b4d785382e9fba5606b49e6c1097', 'ad3b4568941c50559c88f8d1003ac89f00127922', '1', '1516376640');
INSERT INTO `lovevi_picture` VALUES ('187', '/Uploads/Picture/2018-01-19/5a62127687ec9.jpg', '', 'bf27ce6060f686dde013cbe6fa745ce2', 'edab9eb9a40e0e715055831de525f7a540629069', '1', '1516376694');
INSERT INTO `lovevi_picture` VALUES ('188', '/Uploads/Picture/2018-01-19/5a62128e0626b.jpg', '', '36537a2b925b7303f2e0a19fcd73a50f', '8f5a4d4048d50b693f7a35656864bee5e086ad58', '1', '1516376717');
INSERT INTO `lovevi_picture` VALUES ('189', '/Uploads/Picture/2018-01-19/5a6212a70db3d.jpg', '', '7c8ae893d07df872c05a6e9caee2a77b', '6a5d92e94103a9269c036388c4d547c78169d045', '1', '1516376743');
INSERT INTO `lovevi_picture` VALUES ('190', '/Uploads/Picture/2018-01-19/5a6212d1ead21.jpg', '', 'c5b2b54f153a73a008d080c9583ad0b4', '79385b74513cc1e58acc321d979de141740320ad', '1', '1516376785');
INSERT INTO `lovevi_picture` VALUES ('191', '/Uploads/Picture/2018-01-19/5a6212ee69083.jpg', '', '19b7f9cd4452f672121b92c5b2e496cc', 'cc24231ca6d3ff5d89666dd77ce4149789d5ed7f', '1', '1516376814');
INSERT INTO `lovevi_picture` VALUES ('192', '/Uploads/Picture/2018-01-19/5a62133e46734.jpg', '', '395d00928a64bb66ede1dd673ccc74ab', '3833b9011ff35f713ee0884f6c1a37eea3c3fc4b', '1', '1516376894');
INSERT INTO `lovevi_picture` VALUES ('193', '/Uploads/Picture/2018-01-20/5a62a8c2ac46e.jpg', '', '7ed8c6237bd6c3bb14d0fb1264f032e9', '3cb84de2701f86d9e10ddb2a228a1d41808ee9eb', '1', '1516415170');
INSERT INTO `lovevi_picture` VALUES ('194', '/Uploads/Picture/2018-01-20/5a62a8dc0c0f4.jpg', '', '905574c837421a25d34852c7bfd177cd', 'd9bd4f5faf895e89374b71000bc34328b9c2deb2', '1', '1516415195');
INSERT INTO `lovevi_picture` VALUES ('195', '/Uploads/Picture/2018-01-20/5a62a900730e7.jpg', '', '35852d43b5681a3d7f4ff6047db533b9', '9a22287db51ff8d089924436613b26ba044c9129', '1', '1516415232');
INSERT INTO `lovevi_picture` VALUES ('196', '/Uploads/Picture/2018-01-20/5a62a93386214.jpg', '', '38b4d32c6e8fd6e9ce82a86406d86b64', '1811da59b274723a736c251162bc5b2786f62629', '1', '1516415283');
INSERT INTO `lovevi_picture` VALUES ('197', '/Uploads/Picture/2018-01-20/5a62a95db7b89.jpg', '', 'f14ea42019ab1136ed122fa750ef2f83', 'dddd3222ac601d2969577594cba7f16d61fae419', '1', '1516415325');
INSERT INTO `lovevi_picture` VALUES ('198', '/Uploads/Picture/2018-01-20/5a62a98626c33.jpg', '', '57abef220f498dfe4e35af8934244bbf', 'ed4d244df526d0a984ab6b420a64ce6387293851', '1', '1516415366');
INSERT INTO `lovevi_picture` VALUES ('199', '/Uploads/Picture/2018-01-20/5a62a9ad9d04a.jpg', '', '77a687d4c1580be507cd5ae06815fa62', '40d39a5dbbdcf9cf77e01e92068e8c7ee0e4204b', '1', '1516415405');
INSERT INTO `lovevi_picture` VALUES ('200', '/Uploads/Picture/2018-01-20/5a62a9cb730e7.jpg', '', 'fd4a8349a2ea0c0e73bcab8feeb68d2c', '14e212c084d0a126431d454cf18724134ea77add', '1', '1516415435');
INSERT INTO `lovevi_picture` VALUES ('201', '/Uploads/Picture/2018-01-20/5a62a9efac46e.jpg', '', '33135fb28857d053f4a764642449f855', 'e0a9010e9d02395f97e816b8f61c3a1e101c28b0', '1', '1516415471');
INSERT INTO `lovevi_picture` VALUES ('202', '/Uploads/Picture/2018-01-20/5a62aa0aa8765.jpg', '', 'cdd180332b1ba441e4484518c7af809f', 'ffa537fdd4ad9869feac7b0882b248426543bde0', '1', '1516415498');
INSERT INTO `lovevi_picture` VALUES ('203', '/Uploads/Picture/2018-01-20/5a62aa3086214.jpg', '', '9513af5e83e7e32367d62eb5e339ed5a', '2f9e46f26a13564ee00d92fd942ec3c28c7b0b0e', '1', '1516415536');
INSERT INTO `lovevi_picture` VALUES ('204', '/Uploads/Picture/2018-01-20/5a62aa556b6d5.jpg', '', 'b19a31954b680705a64dff88eb7d3a8f', 'd1dea7b86a8e12211496e2d420879d00c6249a34', '1', '1516415573');
INSERT INTO `lovevi_picture` VALUES ('205', '/Uploads/Picture/2018-01-20/5a62aa801f221.jpg', '', 'cdff2be08f8aebffe832ec0e05087686', 'dddc9ecd4713651deb0dbdc116af7ad41023fee1', '1', '1516415615');
INSERT INTO `lovevi_picture` VALUES ('206', '/Uploads/Picture/2018-01-20/5a62aacb36057.jpg', '', '9749a98d94979bbf0698853041df3b05', 'df5df125054a7176d2aea73144e657915a6bebe0', '1', '1516415691');
INSERT INTO `lovevi_picture` VALUES ('207', '/Uploads/Picture/2018-01-20/5a62aaf976df0.jpg', '', '77b175a1e1e928a35e928c9f4cc64aba', 'e887ea7cb5642f4bb8ad8b3a0251ab84e1403b8f', '1', '1516415737');
INSERT INTO `lovevi_picture` VALUES ('208', '/Uploads/Picture/2018-01-20/5a62ab3299341.jpg', '', '038bfc99f634cc8feff704140965e94f', '06a8d8854feae1b744d28097e78e55523126cb59', '1', '1516415794');
INSERT INTO `lovevi_picture` VALUES ('209', '/Uploads/Picture/2018-01-20/5a630c7f585a8.jpg', '', 'ce8a4183c61154677cc7501853cf26a9', '6d3696c7ceb6fb45ff2b93ba009b53aac59abe9d', '1', '1516440702');
INSERT INTO `lovevi_picture` VALUES ('210', '/Uploads/Picture/2018-01-21/5a6372feb848b.jpg', '', 'aba781781fc50282f1103bbd643d2920', '3a071cb6b7837abdd73b1f37697a39785841697d', '1', '1516466941');
INSERT INTO `lovevi_picture` VALUES ('211', '/Uploads/Picture/2018-01-21/5a63794e973dd.jpg', '', '9c18ac351cc0a6963f51a80a34be9365', '1d4b3565b9d0afc00946c14230dd516bf509a54f', '1', '1516468557');
INSERT INTO `lovevi_picture` VALUES ('212', '/Uploads/Picture/2018-01-21/5a638b92679cc.jpg', '', '2c6620943120b288540d17faa2ac1198', 'a333bd8eedb39de5d6329461ff0a7226d2d12961', '1', '1516473234');
INSERT INTO `lovevi_picture` VALUES ('213', '/Uploads/Picture/2018-01-21/5a638e1d5489f.jpg', '', 'd8cb7231c61d1267f7ef1faf6adc463b', '3d98dbcfddb1625e15f586427d571878e1d5f70a', '1', '1516473884');
INSERT INTO `lovevi_picture` VALUES ('214', '/Uploads/Picture/2018-01-21/5a6464b2eb510.jpg', '', 'e6a443c71c252a1df8aa83bd25ba808c', 'd26fabe3eff1f29a8d89f7a2bc6f0e3681c2cf76', '1', '1516528817');
INSERT INTO `lovevi_picture` VALUES ('215', '/Uploads/Picture/2018-01-21/5a646f0ba6a6e.jpg', '', '844729e8267b9e737b794fb3104d65a4', '546317c38f26b7ad14e56fa57649421426edb8c6', '1', '1516531465');
INSERT INTO `lovevi_picture` VALUES ('216', '/Uploads/Picture/2018-01-22/5a65b70b34360.jpg', '', '37a8d4032aefe98b2e5dad3ccb0482ca', '44cdf2edb90679b982267502e8731222aacae112', '1', '1516615434');
INSERT INTO `lovevi_picture` VALUES ('217', '/Uploads/Picture/2018-01-23/5a661c12a3b58.png', '', '12ff705b03bc8b8b62a53ca343551351', '50c19ea7b72305d73d03d3ae5d14155b23c20726', '1', '1516641297');
INSERT INTO `lovevi_picture` VALUES ('218', '/Uploads/Picture/2018-01-23/5a661cef7de83.jpg', '', '5fe86204008b132b32fdd4cfdc84e823', 'fa61d1e4395d50e3affab50cd2b8f985fe8a6da4', '1', '1516641519');
INSERT INTO `lovevi_picture` VALUES ('219', '/Uploads/Picture/2018-01-23/5a661dc74cb32.jpg', '', '73b490d3d8316d7230dbbc54ad34a48e', '4053cae48aa7f73098e768143cfa5c764ccee75f', '1', '1516641735');
INSERT INTO `lovevi_picture` VALUES ('220', '/Uploads/Picture/2018-01-23/5a661ea46076c.png', '', '5f70b94061c86d28ba9e39978822c7d0', '8ddb6385bd90f6428dc16a617e0a3d0233b27e77', '1', '1516641955');
INSERT INTO `lovevi_picture` VALUES ('221', '/Uploads/Picture/2018-01-23/5a66ff59535c8.png', '', '62be3dd8ce374c1811fa0f769381a0e5', 'e806805102ee1f5fdfb20457dc1cdd6b967180b5', '1', '1516699481');
INSERT INTO `lovevi_picture` VALUES ('222', '/Uploads/Picture/2018-01-23/5a674f97d67bb.jpg', '', '487bff330d46fc041ba15c67e979490f', '7f21a7700c9f1480cf19dace1ca573307e10f7fe', '1', '1516720022');
INSERT INTO `lovevi_picture` VALUES ('223', '/Uploads/Picture/2018-01-23/5a67531132738.jpg', '', 'b5636902c5aa18574260f85f2ec4584e', '45e6f2621e47d1fc9353fd705c06ad3de78d60f3', '1', '1516720911');
INSERT INTO `lovevi_picture` VALUES ('224', '/Uploads/Picture/2018-01-25/5a6974dece015.jpg', '', '2f6519452a17c20b1d7285db4a4e0df4', '9af32ee417e991100fd0de902665eeb9c6ac3d8c', '1', '1516860638');
INSERT INTO `lovevi_picture` VALUES ('225', '/Uploads/Picture/2018-01-25/5a6974fb53ef5.jpg', '', '6252234b5878812a768e548cf9d83e3b', '54c8d50c198f6d7fb1da75b746bf1e4878b9eeb9', '1', '1516860667');
INSERT INTO `lovevi_picture` VALUES ('226', '/Uploads/Picture/2018-02-05/5a78346910d0d.jpg', '', '379aa55693467b5f7b1014ba309911ca', 'f26a62be439464d16d097a25be34c61771b4ff71', '1', '1517827176');
INSERT INTO `lovevi_picture` VALUES ('227', '/Uploads/Picture/2018-02-07/5a7b041c64c0b.jpg', '', 'c082609926658f7fe45a8ad06f32450c', '84096f9bdde79faec52014d5d6fab4481bfb2dea', '1', '1518011420');
INSERT INTO `lovevi_picture` VALUES ('228', '/Uploads/Picture/2018-02-09/5a7d95e568011.png', '', '05bcb5c3ff4351ab39369c705f89db70', 'd390453947c6040d8f2183dd656a71c346b910f4', '1', '1518179813');

-- -----------------------------
-- Table structure for `lovevi_port`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_port`;
CREATE TABLE `lovevi_port` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region` varchar(20) DEFAULT NULL COMMENT '区域',
  `country` varchar(20) DEFAULT NULL COMMENT '国家',
  `port` varchar(20) DEFAULT NULL COMMENT '港口',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='港口';


-- -----------------------------
-- Table structure for `lovevi_tconfig`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_tconfig`;
CREATE TABLE `lovevi_tconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `qq` int(11) DEFAULT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `wpic` varchar(100) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `banner` varchar(100) DEFAULT NULL COMMENT '头图',
  `email` varchar(50) DEFAULT NULL,
  `copyright` varchar(100) DEFAULT NULL,
  `content` text COMMENT '公司介绍',
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `lovevi_tconfig`
-- -----------------------------
INSERT INTO `lovevi_tconfig` VALUES ('1', '晓晨网络', '66329180', '/Uploads/admin/160795004459.jpg', '/Uploads/admin/160795013085.jpg', '18363038888', '/Uploads/admin/160795004886.jpg', '66329180@qq.com', 'Copyright©2015 晓晨网络科技有限公司 版权所有', '<div class=\"thridpage_content_det\">\r\n	<div class=\"thridpage_content_det_left\">\r\n		<div class=\"thridpage_content_det_left_top\">\r\n			上海锋趣网络科技有限公司（简称：上海锋趣）成立于2010年，隶属于成都领沃网络技术有限公司。作为国内先进在线娱乐内容供应商，公司发展迅猛，其旗下品牌“飞火娱乐”拥有“飞火游戏”、“飞火动态壁纸”、“飞火手游助手”、“飞火电竞”以及“极速浏览器”等一系列应用产品。针对网吧、网咖的娱乐需求，公司为玩家提供精彩的娱乐体验；以专业网吧运营平台“云更新”为载体，公司致力于创造一站式平台娱乐内容解决方案。\r\n		</div>\r\n		<div class=\"thridpage_content_det_left_btn\">\r\n			在未来，上海锋趣将继续依托“云更新”在当前网吧市场累积的庞大终端覆盖量，坚持运作互联网信息时代下的创新型公司；坚持在内容合作、渠道建设领域的投入深耕，保持内容精品度和覆盖度的先进地位；同时将携手渠道伙伴，持续与全国知名CP公司建立合作关系，多元化发展互联网增值服务，全面实现跨界整合、互利共赢。\r\n		</div>\r\n	</div>\r\n	<div class=\"thridpage_content_det_right\">\r\n		<img src=\"/public/home/img/building.png\" /> \r\n	</div>\r\n</div>', '晓晨网络');

-- -----------------------------
-- Table structure for `lovevi_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_ucenter_admin`;
CREATE TABLE `lovevi_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='管理员表';


-- -----------------------------
-- Table structure for `lovevi_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_ucenter_app`;
CREATE TABLE `lovevi_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL DEFAULT '' COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL DEFAULT '' COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='应用表';


-- -----------------------------
-- Table structure for `lovevi_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_ucenter_member`;
CREATE TABLE `lovevi_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='用户表';

-- -----------------------------
-- Records of `lovevi_ucenter_member`
-- -----------------------------
INSERT INTO `lovevi_ucenter_member` VALUES ('1', 'admin', '3ebef0f5b4af37beb54960a13535c03e', '123@qq.com', '', '1517827370', '2423999353', '1607945040', '1863220392', '1517827370', '1');
INSERT INTO `lovevi_ucenter_member` VALUES ('31', '太宝', '0aa5064b03792819be9c9e08fac1f7a0', '', '', '1490440335', '1967868805', '0', '0', '1490440335', '1');
INSERT INTO `lovevi_ucenter_member` VALUES ('32', 'titi', '0aa5064b03792819be9c9e08fac1f7a0', '', '', '1490440707', '1967868805', '1490516775', '1967868805', '1490440707', '1');
INSERT INTO `lovevi_ucenter_member` VALUES ('33', 'bbs', '0aa5064b03792819be9c9e08fac1f7a0', '', '', '1490516881', '1967868805', '0', '0', '1490516881', '1');
INSERT INTO `lovevi_ucenter_member` VALUES ('34', 'dog', '0aa5064b03792819be9c9e08fac1f7a0', '', '', '1490517072', '1967868805', '1491139464', '1967869860', '1490517072', '1');
INSERT INTO `lovevi_ucenter_member` VALUES ('35', 'ABC', '3ebef0f5b4af37beb54960a13535c03e', '', '', '1490940879', '1967868805', '0', '0', '1490940879', '1');
INSERT INTO `lovevi_ucenter_member` VALUES ('36', 'test', '055598d3bb4f7227488719a4105552b9', 'aaa1@qq.com', '', '1607950805', '3074809391', '1607951462', '3074809391', '1607950805', '1');

-- -----------------------------
-- Table structure for `lovevi_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_ucenter_setting`;
CREATE TABLE `lovevi_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='设置表';


-- -----------------------------
-- Table structure for `lovevi_url`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_url`;
CREATE TABLE `lovevi_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='链接表';


-- -----------------------------
-- Table structure for `lovevi_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_userdata`;
CREATE TABLE `lovevi_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED;


-- -----------------------------
-- Table structure for `lovevi_users`
-- -----------------------------
DROP TABLE IF EXISTS `lovevi_users`;
CREATE TABLE `lovevi_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user` varchar(255) NOT NULL COMMENT '用户',
  `pwd` varchar(255) NOT NULL COMMENT '密码',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '真实姓名',
  `pic` varchar(255) NOT NULL DEFAULT '/public/home/images/user/default.png',
  `tel` varchar(15) NOT NULL DEFAULT '0' COMMENT '手机',
  `time` int(10) unsigned NOT NULL COMMENT '时间',
  `dtime` int(11) DEFAULT NULL COMMENT '登陆时间',
  `rtime` int(11) DEFAULT NULL COMMENT '注册时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

