-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : fly
-- 
-- Part : #1
-- Date : 2020-12-15 00:21:19
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;

